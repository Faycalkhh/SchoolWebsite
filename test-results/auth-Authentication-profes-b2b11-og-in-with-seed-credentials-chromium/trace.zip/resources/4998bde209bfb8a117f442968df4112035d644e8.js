(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/translations/ar.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const ar = {
    nav: {
        home: "الرئيسية",
        about: "عنّا",
        professors: "الأساتذة",
        facilities: "المرافق",
        students: "الطلاب",
        contact: "تواصل",
        join: "انضم الآن"
    },
    hero: {
        badge: "أهلاً بكم في مدرستنا",
        title1: "مدرسة",
        title2: "نور القرآن",
        subtitle: "ننير القلوب والعقول بنور القرآن الكريم.",
        cta1: "انضم إلينا",
        cta2: "اعرف أكثر",
        scroll: "اكتشف",
        stat1: "طالب",
        stat2: "أستاذ",
        stat3: "سنة"
    },
    about: {
        label: "عنّا",
        title: "مسيرة من التميز",
        highlight: "القرآني",
        desc: "تأسست مدرسة نور القرآن لتقديم تعليم قرآني راقٍ في بيئة إسلامية دافئة ومحفّزة.",
        values: [
            "تعليم التجويد الشخصي لكل طالب",
            "برامج حفظ من جزء عمّ إلى الختمة الكاملة",
            "أساتذة متخصصون وذوو خبرة",
            "بيئة تعليمية آمنة وملهمة"
        ],
        cta: "تعرف على أساتذتنا",
        floatNum: "12+",
        floatLabel: "سنة تميز",
        floatDesc: "ثقة المئات من الأسر"
    },
    professors: {
        label: "هيئة التدريس",
        title: "تعرف على",
        highlight: "أساتذتنا",
        subtitle: "علماء متخصصون يجمعون العلم الشرعي وخبرة التدريس."
    },
    facilities: {
        label: "الحرم الدراسي",
        title: "مرافق",
        highlight: "متميزة",
        subtitle: "بيئة تعليمية محفّزة ومريحة لكل طالب.",
        items: [
            {
                title: "قاعة الدراسة الرئيسية",
                desc: "مساحة رحبة للتعلم الجماعي والتلاوة."
            },
            {
                title: "غرف الدراسة الفردية",
                desc: "جلسات خاصة مع الأستاذ."
            },
            {
                title: "مركز الأطفال",
                desc: "بيئة ملوّنة ومشوّقة للناشئين."
            },
            {
                title: "المكتبة الإسلامية",
                desc: "مراجع قرآنية وكتب إسلامية متنوعة."
            },
            {
                title: "الساحة الخارجية",
                desc: "فضاء للتأمل والراحة."
            },
            {
                title: "مختبر التعلم الرقمي",
                desc: "أدوات حديثة تعزز التعليم التقليدي."
            }
        ]
    },
    students: {
        label: "لوحة الشرف",
        badge: "لوحة الشرف الأسبوعية",
        title: "أفضل الطلاب",
        highlight: "لهذا الأسبوع",
        subtitle: "نحتفي بالطلاب المتميزين في مسيرتهم القرآنية.",
        quote: '"خيركم من تعلّم القرآن وعلّمه"',
        quoteAuthor: "— النبي محمد ﷺ"
    },
    contact: {
        label: "تواصل معنا",
        title: "اتصل",
        highlight: "بنا",
        subtitle: "نسعد بتواصلكم وإجابة استفساراتكم.",
        addressLabel: "العنوان",
        addressValue: "١٤ شارع النور، الحي الإسلامي",
        phoneLabel: "الهاتف",
        phoneValue: "+213 55 012 3456",
        emailLabel: "البريد الإلكتروني",
        emailValue: "info@nuralquran.edu",
        hoursLabel: "ساعات العمل",
        hoursValue: "السبت – الخميس: ٨ص – ٨م",
        formName: "الاسم الكامل",
        formNamePh: "اسمك الكامل",
        formEmail: "البريد الإلكتروني",
        formEmailPh: "بريدك الإلكتروني",
        formPhonePh: "رقم هاتفك",
        formMessage: "رسالتك",
        formMessagePh: "كيف يمكننا مساعدتك؟",
        submit: "إرسال الرسالة",
        sentTitle: "تم إرسال رسالتك!",
        sentDesc: "جزاكم الله خيراً. سنتواصل معك خلال ٢٤ ساعة إن شاء الله.",
        map: "الخريطة التفاعلية قريباً"
    },
    footer: {
        tagline: "ننير القلوب بنور القرآن منذ ٢٠١٢.",
        quickLinks: "روابط سريعة",
        programs: "برامجنا",
        programsList: [
            "التجويد والتلاوة",
            "حفظ القرآن",
            "اللغة العربية",
            "الدراسات الإسلامية",
            "برنامج الأطفال"
        ],
        newsletter: "ابقَ على تواصل",
        newsletterDesc: "اشترك لمتابعة آخر الأخبار.",
        emailPh: "بريدك الإلكتروني",
        ctaTitle: "ابدأ رحلتك القرآنية اليوم",
        ctaDesc: "انضم إلى مئات الطلاب في طريق النور.",
        ctaBtn: "سجّل الآن",
        rights: "© 2026 مدرسة نور القرآن. جميع الحقوق محفوظة.",
        bottom: "صُمِّم بـ ❤️ لطلاب العلم"
    }
};
const __TURBOPACK__default__export__ = ar;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/translations/fr.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const fr = {
    nav: {
        home: "Accueil",
        about: "À propos",
        professors: "Professeurs",
        facilities: "Installations",
        students: "Étudiants",
        contact: "Contact",
        join: "Rejoindre"
    },
    hero: {
        badge: "Bienvenue dans notre école",
        title1: "École",
        title2: "Nur Al-Quran",
        subtitle: "Illuminer les cœurs et les esprits par la sagesse du Saint Coran.",
        cta1: "Rejoindre l'école",
        cta2: "En savoir plus",
        scroll: "Découvrir",
        stat1: "Étudiants",
        stat2: "Professeurs",
        stat3: "Ans"
    },
    about: {
        label: "À propos",
        title: "Une excellence",
        highlight: "coranique",
        desc: "L'école Nur Al-Quran a été fondée pour offrir un enseignement coranique d'excellence dans un cadre islamique chaleureux.",
        values: [
            "Enseignement personnalisé du Tajweed",
            "Programmes de mémorisation complets",
            "Professeurs qualifiés et expérimentés",
            "Environnement d'apprentissage sûr et inspirant"
        ],
        cta: "Notre équipe",
        floatNum: "12+",
        floatLabel: "ans d'excellence",
        floatDesc: "La confiance de centaines de familles"
    },
    professors: {
        label: "Notre Corps Enseignant",
        title: "Nos",
        highlight: "Professeurs",
        subtitle: "Des érudits alliant savoir islamique et excellence pédagogique."
    },
    facilities: {
        label: "Notre Campus",
        title: "Nos",
        highlight: "Installations",
        subtitle: "Un environnement conçu pour inspirer chaque étudiant.",
        items: [
            {
                title: "Grande Salle d'Étude",
                desc: "Un espace spacieux pour l'apprentissage collectif."
            },
            {
                title: "Salles Individuelles",
                desc: "Sessions privées avec les professeurs."
            },
            {
                title: "Centre pour Enfants",
                desc: "Un espace coloré et ludique pour les plus jeunes."
            },
            {
                title: "Bibliothèque Islamique",
                desc: "Une collection de ressources coraniques."
            },
            {
                title: "Cour Extérieure",
                desc: "Un espace de détente et de réflexion."
            },
            {
                title: "Laboratoire Numérique",
                desc: "Outils modernes pour enrichir l'enseignement."
            }
        ]
    },
    students: {
        label: "Tableau d'Honneur",
        badge: "Tableau d'Honneur de la Semaine",
        title: "Meilleurs Étudiants",
        highlight: "de la Semaine",
        subtitle: "Célébrons nos étudiants les plus méritants.",
        quote: '"Le meilleur est celui qui apprend le Coran et l\'enseigne."',
        quoteAuthor: "— Prophète Muhammad ﷺ"
    },
    contact: {
        label: "Contactez-nous",
        title: "Nous",
        highlight: "Contacter",
        subtitle: "Nous sommes là pour répondre à toutes vos questions.",
        addressLabel: "Adresse",
        addressValue: "14 Rue Al-Nour, Quartier Islamique",
        phoneLabel: "Téléphone",
        phoneValue: "+213 55 012 3456",
        emailLabel: "Email",
        emailValue: "info@nuralquran.edu",
        hoursLabel: "Horaires",
        hoursValue: "Sam – Jeu : 8h – 20h",
        formName: "Nom complet",
        formNamePh: "Votre nom complet",
        formEmail: "Adresse email",
        formEmailPh: "votre@email.com",
        formPhonePh: "+213 55 000 0000",
        formMessage: "Message",
        formMessagePh: "Comment pouvons-nous vous aider ?",
        submit: "Envoyer le message",
        sentTitle: "Message envoyé !",
        sentDesc: "Nous vous répondrons dans les 24h, incha'Allah.",
        map: "Carte interactive bientôt disponible"
    },
    footer: {
        tagline: "Illuminer les cœurs par le Coran depuis 2012.",
        quickLinks: "Liens rapides",
        programs: "Nos programmes",
        programsList: [
            "Tajweed & Récitation",
            "Mémorisation du Coran",
            "Langue arabe",
            "Études islamiques",
            "Programme enfants"
        ],
        newsletter: "Restez informé",
        newsletterDesc: "Abonnez-vous pour suivre les actualités.",
        emailPh: "Votre email",
        ctaTitle: "Commencez votre parcours coranique",
        ctaDesc: "Rejoignez des centaines d'étudiants sur la voie de la lumière.",
        ctaBtn: "S'inscrire",
        rights: "© 2026 École Nur Al-Quran. Tous droits réservés.",
        bottom: "Conçu avec ❤️ pour les chercheurs de savoir"
    }
};
const __TURBOPACK__default__export__ = fr;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/LanguageContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LanguageProvider",
    ()=>LanguageProvider,
    "useLanguage",
    ()=>useLanguage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$translations$2f$ar$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/translations/ar.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$translations$2f$fr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/translations/fr.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const translations = {
    ar: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$translations$2f$ar$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    fr: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$translations$2f$fr$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
};
const LanguageContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    lang: "ar",
    setLang: ()=>{},
    T: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$translations$2f$ar$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    dir: "rtl"
});
function LanguageProvider({ children }) {
    _s();
    const [lang, setLang] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("ar");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LanguageProvider.useEffect": ()=>{
            document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
            document.documentElement.lang = lang;
        }
    }["LanguageProvider.useEffect"], [
        lang
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LanguageContext.Provider, {
        value: {
            lang,
            setLang,
            T: translations[lang],
            dir: lang === "ar" ? "rtl" : "ltr"
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/LanguageContext.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(LanguageProvider, "hJWTgXp3IxnlDsO65GY85QNpRsc=");
_c = LanguageProvider;
const useLanguage = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(LanguageContext);
};
_s1(useLanguage, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "LanguageProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/supabase.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-client] (ecmascript) <locals>");
;
const url = ("TURBOPACK compile-time value", "https://jalyyvclrezcuksconxk.supabase.co");
const anon = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImphbHl5dmNscmV6Y3Vrc2NvbnhrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgwNzEyNjYsImV4cCI6MjA5MzY0NzI2Nn0._-SVIgMDwYI9ciQtEu3AsUVAZ7KsXUDKYcxbD7rtAYs");
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, anon);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addAnnouncement",
    ()=>addAnnouncement,
    "addExam",
    ()=>addExam,
    "addExamResult",
    ()=>addExamResult,
    "addSession",
    ()=>addSession,
    "addStudent",
    ()=>addStudent,
    "createUser",
    ()=>createUser,
    "deleteAnnouncement",
    ()=>deleteAnnouncement,
    "deleteExam",
    ()=>deleteExam,
    "deleteExamResults",
    ()=>deleteExamResults,
    "deleteProfile",
    ()=>deleteProfile,
    "deleteStudent",
    ()=>deleteStudent,
    "getAnnouncements",
    ()=>getAnnouncements,
    "getExamResults",
    ()=>getExamResults,
    "getExams",
    ()=>getExams,
    "getProfiles",
    ()=>getProfiles,
    "getSessionUser",
    ()=>getSessionUser,
    "getStudents",
    ()=>getStudents,
    "getStudentsByParent",
    ()=>getStudentsByParent,
    "getTopStudents",
    ()=>getTopStudents,
    "saveMemoMap",
    ()=>saveMemoMap,
    "saveTopStudents",
    ()=>saveTopStudents,
    "signIn",
    ()=>signIn,
    "signOut",
    ()=>signOut,
    "updateStudent",
    ()=>updateStudent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase.ts [app-client] (ecmascript)");
;
// ── helpers ──────────────────────────────────────────────────
function mapSession(r) {
    return {
        id: r.id,
        date: r.date,
        present: r.present,
        discipline: r.discipline,
        memorization: r.memorization ?? "",
        comment: r.comment ?? "",
        professorId: r.professor_id
    };
}
function mapStudent(r) {
    const rawSessions = r.sessions ?? [];
    const rawMemo = r.student_memorization ?? [];
    const memorization = {};
    rawMemo.forEach(({ surah_number, status })=>{
        memorization[surah_number] = status;
    });
    return {
        id: r.id,
        name: r.name,
        age: r.age,
        level: r.level,
        parentId: r.parent_id,
        photo: r.photo ?? undefined,
        sessions: rawSessions.sort((a, b)=>String(b.date).localeCompare(String(a.date))).map(mapSession),
        memorization: Object.keys(memorization).length ? memorization : undefined
    };
}
function mapExam(r) {
    const rawQs = r.qcm_questions ?? [];
    const questions = rawQs.sort((a, b)=>a.position - b.position).map((q)=>({
            id: q.id,
            text: q.text,
            correctOptionId: q.correct_option_id,
            options: (q.qcm_options ?? []).map((o)=>({
                    id: o.id,
                    text: o.text
                }))
        }));
    return {
        id: r.id,
        title: r.title,
        professorId: r.professor_id,
        date: r.date,
        questions
    };
}
async function getProfiles() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("profiles").select("*").order("created_at");
    return (data ?? []).map((p)=>({
            id: p.id,
            name: p.name,
            email: p.email ?? "",
            password: "",
            role: p.role,
            specialty: p.specialty ?? undefined
        }));
}
async function createUser(email, password, name, role, specialty) {
    const res = await fetch("/api/create-user", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email,
            password,
            name,
            role,
            specialty
        })
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.error ?? "Failed to create user");
    return {
        id: json.user.id,
        name: json.user.name,
        email,
        password,
        role,
        specialty
    };
}
async function deleteProfile(id) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("profiles").delete().eq("id", id);
}
async function getStudents() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("students").select("*, sessions(*), student_memorization(*)").order("created_at");
    return (data ?? []).map(mapStudent);
}
async function getStudentsByParent(parentId) {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("students").select("*, sessions(*), student_memorization(*)").eq("parent_id", parentId).order("created_at");
    return (data ?? []).map(mapStudent);
}
async function addStudent(name, age, level, parentId, photo) {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("students").insert({
        name,
        age,
        level,
        parent_id: parentId,
        photo: photo ?? null
    }).select("*, sessions(*), student_memorization(*)").single();
    return mapStudent(data);
}
async function updateStudent(id, patch) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("students").update({
        name: patch.name,
        age: patch.age,
        level: patch.level,
        photo: patch.photo ?? null
    }).eq("id", id);
}
async function deleteStudent(id) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("students").delete().eq("id", id);
}
async function addSession(studentId, professorId, data) {
    const { data: row } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("sessions").insert({
        student_id: studentId,
        professor_id: professorId,
        date: data.date,
        present: data.present,
        discipline: data.discipline,
        memorization: data.memorization,
        comment: data.comment
    }).select().single();
    return mapSession(row);
}
async function getTopStudents() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("top_entries").select("*").order("rank");
    return (data ?? []).map((r)=>({
            rank: r.rank,
            studentId: r.student_id
        }));
}
async function saveTopStudents(entries) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("top_entries").delete().neq("rank", 0);
    if (entries.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("top_entries").insert(entries.map((e)=>({
                rank: e.rank,
                student_id: e.studentId
            })));
    }
}
async function getAnnouncements() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("announcements").select("*").order("created_at", {
        ascending: false
    });
    return (data ?? []).map((a)=>({
            id: a.id,
            title: a.title,
            body: a.body,
            image: a.image ?? undefined,
            date: a.date
        }));
}
async function addAnnouncement(ann) {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("announcements").insert({
        title: ann.title,
        body: ann.body,
        image: ann.image ?? null,
        date: ann.date
    }).select().single();
    return {
        id: data.id,
        title: data.title,
        body: data.body,
        image: data.image ?? undefined,
        date: data.date
    };
}
async function deleteAnnouncement(id) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("announcements").delete().eq("id", id);
}
async function getExams() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("exams").select("*, qcm_questions(*, qcm_options(*))").order("created_at", {
        ascending: false
    });
    return (data ?? []).map(mapExam);
}
async function addExam(exam) {
    const { data: examRow } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("exams").insert({
        title: exam.title,
        professor_id: exam.professorId,
        date: exam.date
    }).select().single();
    for(let i = 0; i < exam.questions.length; i++){
        const q = exam.questions[i];
        const { data: qRow } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("qcm_questions").insert({
            exam_id: examRow.id,
            text: q.text,
            correct_option_id: q.correctOptionId,
            position: i
        }).select().single();
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("qcm_options").insert(q.options.map((o)=>({
                id: o.id,
                question_id: qRow.id,
                text: o.text
            })));
    }
}
async function deleteExam(id) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("exams").delete().eq("id", id);
}
async function getExamResults() {
    const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("exam_results").select("*").order("created_at", {
        ascending: false
    });
    return (data ?? []).map((r)=>({
            id: r.id,
            examId: r.exam_id,
            studentId: r.student_id,
            answers: r.answers,
            score: r.score,
            correctCount: r.correct_count,
            totalCount: r.total_count,
            dateTaken: r.date_taken
        }));
}
async function addExamResult(result) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("exam_results").insert({
        exam_id: result.examId,
        student_id: result.studentId,
        answers: result.answers,
        score: result.score,
        correct_count: result.correctCount,
        total_count: result.totalCount,
        date_taken: result.dateTaken
    });
}
async function deleteExamResults(examId) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("exam_results").delete().eq("exam_id", examId);
}
async function saveMemoMap(studentId, memo) {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("student_memorization").delete().eq("student_id", studentId);
    const entries = Object.entries(memo).filter(([, status])=>status !== "not_started").map(([n, status])=>({
            student_id: studentId,
            surah_number: Number(n),
            status
        }));
    if (entries.length) {
        await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("student_memorization").insert(entries);
    }
}
async function signIn(email, password) {
    const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.signInWithPassword({
        email,
        password
    });
    if (error || !data.user) {
        console.error("[signIn] auth error:", error?.message, error?.status);
        return null;
    }
    const { data: profile, error: profileError } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("profiles").select("*").eq("id", data.user.id).single();
    if (!profile) {
        console.error("[signIn] profile not found for uid:", data.user.id, profileError?.message);
        return null;
    }
    return {
        id: profile.id,
        name: profile.name,
        email: data.user.email ?? "",
        password: "",
        role: profile.role,
        specialty: profile.specialty ?? undefined
    };
}
async function signOut() {
    await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.signOut();
}
async function getSessionUser() {
    const { data: { user } } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.getUser();
    if (!user) return null;
    const { data: profile } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].from("profiles").select("*").eq("id", user.id).single();
    if (!profile) return null;
    return {
        id: profile.id,
        name: profile.name,
        email: user.email ?? "",
        password: "",
        role: profile.role,
        specialty: profile.specialty ?? undefined
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/AuthContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AuthProvider",
    ()=>AuthProvider,
    "useAuth",
    ()=>useAuth
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    user: null,
    loading: true,
    logout: async ()=>{}
});
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            // Load user from current Supabase session on mount
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSessionUser"])().then({
                "AuthProvider.useEffect": (u)=>{
                    setUser(u);
                    setLoading(false);
                }
            }["AuthProvider.useEffect"]);
            // Keep in sync with Supabase auth state changes (sign-in / sign-out)
            const { data: { subscription } } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.onAuthStateChange({
                "AuthProvider.useEffect": async (event)=>{
                    if (event === "SIGNED_OUT") {
                        setUser(null);
                    } else {
                        const u = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSessionUser"])();
                        setUser(u);
                    }
                }
            }["AuthProvider.useEffect"]);
            return ({
                "AuthProvider.useEffect": ()=>subscription.unsubscribe()
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], []);
    async function logout() {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signOut"])();
        setUser(null);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            loading,
            logout
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/context/AuthContext.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "NiO5z6JIqzX62LS5UWDgIqbZYyY=");
_c = AuthProvider;
const useAuth = ()=>{
    _s1();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
};
_s1(useAuth, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Providers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
"use client";
;
;
;
function Providers({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LanguageProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthProvider"], {
            children: children
        }, void 0, false, {
            fileName: "[project]/src/components/Providers.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/Providers.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = Providers;
var _c;
__turbopack_context__.k.register(_c, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ServiceWorker.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ServiceWorker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
function ServiceWorker() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ServiceWorker.useEffect": ()=>{
            if ("serviceWorker" in navigator) {
                navigator.serviceWorker.register("/sw.js").catch({
                    "ServiceWorker.useEffect": ()=>{}
                }["ServiceWorker.useEffect"]);
            }
        }
    }["ServiceWorker.useEffect"], []);
    return null;
}
_s(ServiceWorker, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ServiceWorker;
var _c;
__turbopack_context__.k.register(_c, "ServiceWorker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0vf32uq._.js.map