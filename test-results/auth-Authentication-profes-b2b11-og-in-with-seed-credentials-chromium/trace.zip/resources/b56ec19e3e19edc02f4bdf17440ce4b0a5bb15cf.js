(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/quran.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "JUZ_SURAHS",
    ()=>JUZ_SURAHS,
    "SURAHS",
    ()=>SURAHS,
    "countMemorized",
    ()=>countMemorized
]);
const SURAHS = [
    {
        n: 1,
        ar: "الفاتحة",
        fr: "Al-Fatiha",
        juz: 1,
        ayahs: 7
    },
    {
        n: 2,
        ar: "البقرة",
        fr: "Al-Baqara",
        juz: 1,
        ayahs: 286
    },
    {
        n: 3,
        ar: "آل عمران",
        fr: "Ali Imran",
        juz: 3,
        ayahs: 200
    },
    {
        n: 4,
        ar: "النساء",
        fr: "An-Nisa",
        juz: 4,
        ayahs: 176
    },
    {
        n: 5,
        ar: "المائدة",
        fr: "Al-Ma'ida",
        juz: 6,
        ayahs: 120
    },
    {
        n: 6,
        ar: "الأنعام",
        fr: "Al-An'am",
        juz: 7,
        ayahs: 165
    },
    {
        n: 7,
        ar: "الأعراف",
        fr: "Al-A'raf",
        juz: 8,
        ayahs: 206
    },
    {
        n: 8,
        ar: "الأنفال",
        fr: "Al-Anfal",
        juz: 9,
        ayahs: 75
    },
    {
        n: 9,
        ar: "التوبة",
        fr: "At-Tawba",
        juz: 10,
        ayahs: 129
    },
    {
        n: 10,
        ar: "يونس",
        fr: "Yunus",
        juz: 11,
        ayahs: 109
    },
    {
        n: 11,
        ar: "هود",
        fr: "Hud",
        juz: 11,
        ayahs: 123
    },
    {
        n: 12,
        ar: "يوسف",
        fr: "Yusuf",
        juz: 12,
        ayahs: 111
    },
    {
        n: 13,
        ar: "الرعد",
        fr: "Ar-Ra'd",
        juz: 13,
        ayahs: 43
    },
    {
        n: 14,
        ar: "إبراهيم",
        fr: "Ibrahim",
        juz: 13,
        ayahs: 52
    },
    {
        n: 15,
        ar: "الحجر",
        fr: "Al-Hijr",
        juz: 13,
        ayahs: 99
    },
    {
        n: 16,
        ar: "النحل",
        fr: "An-Nahl",
        juz: 14,
        ayahs: 128
    },
    {
        n: 17,
        ar: "الإسراء",
        fr: "Al-Isra",
        juz: 15,
        ayahs: 111
    },
    {
        n: 18,
        ar: "الكهف",
        fr: "Al-Kahf",
        juz: 15,
        ayahs: 110
    },
    {
        n: 19,
        ar: "مريم",
        fr: "Maryam",
        juz: 16,
        ayahs: 98
    },
    {
        n: 20,
        ar: "طه",
        fr: "Ta-Ha",
        juz: 16,
        ayahs: 135
    },
    {
        n: 21,
        ar: "الأنبياء",
        fr: "Al-Anbiya",
        juz: 17,
        ayahs: 112
    },
    {
        n: 22,
        ar: "الحج",
        fr: "Al-Hajj",
        juz: 17,
        ayahs: 78
    },
    {
        n: 23,
        ar: "المؤمنون",
        fr: "Al-Mu'minun",
        juz: 18,
        ayahs: 118
    },
    {
        n: 24,
        ar: "النور",
        fr: "An-Nur",
        juz: 18,
        ayahs: 64
    },
    {
        n: 25,
        ar: "الفرقان",
        fr: "Al-Furqan",
        juz: 18,
        ayahs: 77
    },
    {
        n: 26,
        ar: "الشعراء",
        fr: "Ash-Shu'ara",
        juz: 19,
        ayahs: 227
    },
    {
        n: 27,
        ar: "النمل",
        fr: "An-Naml",
        juz: 19,
        ayahs: 93
    },
    {
        n: 28,
        ar: "القصص",
        fr: "Al-Qasas",
        juz: 20,
        ayahs: 88
    },
    {
        n: 29,
        ar: "العنكبوت",
        fr: "Al-Ankabut",
        juz: 20,
        ayahs: 69
    },
    {
        n: 30,
        ar: "الروم",
        fr: "Ar-Rum",
        juz: 21,
        ayahs: 60
    },
    {
        n: 31,
        ar: "لقمان",
        fr: "Luqman",
        juz: 21,
        ayahs: 34
    },
    {
        n: 32,
        ar: "السجدة",
        fr: "As-Sajda",
        juz: 21,
        ayahs: 30
    },
    {
        n: 33,
        ar: "الأحزاب",
        fr: "Al-Ahzab",
        juz: 21,
        ayahs: 73
    },
    {
        n: 34,
        ar: "سبأ",
        fr: "Saba",
        juz: 22,
        ayahs: 54
    },
    {
        n: 35,
        ar: "فاطر",
        fr: "Fatir",
        juz: 22,
        ayahs: 45
    },
    {
        n: 36,
        ar: "يس",
        fr: "Ya-Sin",
        juz: 22,
        ayahs: 83
    },
    {
        n: 37,
        ar: "الصافات",
        fr: "As-Saffat",
        juz: 23,
        ayahs: 182
    },
    {
        n: 38,
        ar: "ص",
        fr: "Sad",
        juz: 23,
        ayahs: 88
    },
    {
        n: 39,
        ar: "الزمر",
        fr: "Az-Zumar",
        juz: 23,
        ayahs: 75
    },
    {
        n: 40,
        ar: "غافر",
        fr: "Ghafir",
        juz: 24,
        ayahs: 85
    },
    {
        n: 41,
        ar: "فصلت",
        fr: "Fussilat",
        juz: 24,
        ayahs: 54
    },
    {
        n: 42,
        ar: "الشورى",
        fr: "Ash-Shura",
        juz: 25,
        ayahs: 53
    },
    {
        n: 43,
        ar: "الزخرف",
        fr: "Az-Zukhruf",
        juz: 25,
        ayahs: 89
    },
    {
        n: 44,
        ar: "الدخان",
        fr: "Ad-Dukhan",
        juz: 25,
        ayahs: 59
    },
    {
        n: 45,
        ar: "الجاثية",
        fr: "Al-Jathiya",
        juz: 25,
        ayahs: 37
    },
    {
        n: 46,
        ar: "الأحقاف",
        fr: "Al-Ahqaf",
        juz: 26,
        ayahs: 35
    },
    {
        n: 47,
        ar: "محمد",
        fr: "Muhammad",
        juz: 26,
        ayahs: 38
    },
    {
        n: 48,
        ar: "الفتح",
        fr: "Al-Fath",
        juz: 26,
        ayahs: 29
    },
    {
        n: 49,
        ar: "الحجرات",
        fr: "Al-Hujurat",
        juz: 26,
        ayahs: 18
    },
    {
        n: 50,
        ar: "ق",
        fr: "Qaf",
        juz: 26,
        ayahs: 45
    },
    {
        n: 51,
        ar: "الذاريات",
        fr: "Adh-Dhariyat",
        juz: 26,
        ayahs: 60
    },
    {
        n: 52,
        ar: "الطور",
        fr: "At-Tur",
        juz: 27,
        ayahs: 49
    },
    {
        n: 53,
        ar: "النجم",
        fr: "An-Najm",
        juz: 27,
        ayahs: 62
    },
    {
        n: 54,
        ar: "القمر",
        fr: "Al-Qamar",
        juz: 27,
        ayahs: 55
    },
    {
        n: 55,
        ar: "الرحمن",
        fr: "Ar-Rahman",
        juz: 27,
        ayahs: 78
    },
    {
        n: 56,
        ar: "الواقعة",
        fr: "Al-Waqi'a",
        juz: 27,
        ayahs: 96
    },
    {
        n: 57,
        ar: "الحديد",
        fr: "Al-Hadid",
        juz: 27,
        ayahs: 29
    },
    {
        n: 58,
        ar: "المجادلة",
        fr: "Al-Mujadila",
        juz: 28,
        ayahs: 22
    },
    {
        n: 59,
        ar: "الحشر",
        fr: "Al-Hashr",
        juz: 28,
        ayahs: 24
    },
    {
        n: 60,
        ar: "الممتحنة",
        fr: "Al-Mumtahina",
        juz: 28,
        ayahs: 13
    },
    {
        n: 61,
        ar: "الصف",
        fr: "As-Saf",
        juz: 28,
        ayahs: 14
    },
    {
        n: 62,
        ar: "الجمعة",
        fr: "Al-Jumu'a",
        juz: 28,
        ayahs: 11
    },
    {
        n: 63,
        ar: "المنافقون",
        fr: "Al-Munafiqun",
        juz: 28,
        ayahs: 11
    },
    {
        n: 64,
        ar: "التغابن",
        fr: "At-Taghabun",
        juz: 28,
        ayahs: 18
    },
    {
        n: 65,
        ar: "الطلاق",
        fr: "At-Talaq",
        juz: 28,
        ayahs: 12
    },
    {
        n: 66,
        ar: "التحريم",
        fr: "At-Tahrim",
        juz: 28,
        ayahs: 12
    },
    {
        n: 67,
        ar: "الملك",
        fr: "Al-Mulk",
        juz: 29,
        ayahs: 30
    },
    {
        n: 68,
        ar: "القلم",
        fr: "Al-Qalam",
        juz: 29,
        ayahs: 52
    },
    {
        n: 69,
        ar: "الحاقة",
        fr: "Al-Haqqah",
        juz: 29,
        ayahs: 52
    },
    {
        n: 70,
        ar: "المعارج",
        fr: "Al-Ma'arij",
        juz: 29,
        ayahs: 44
    },
    {
        n: 71,
        ar: "نوح",
        fr: "Nuh",
        juz: 29,
        ayahs: 28
    },
    {
        n: 72,
        ar: "الجن",
        fr: "Al-Jinn",
        juz: 29,
        ayahs: 28
    },
    {
        n: 73,
        ar: "المزمل",
        fr: "Al-Muzzammil",
        juz: 29,
        ayahs: 20
    },
    {
        n: 74,
        ar: "المدثر",
        fr: "Al-Muddathir",
        juz: 29,
        ayahs: 56
    },
    {
        n: 75,
        ar: "القيامة",
        fr: "Al-Qiyama",
        juz: 29,
        ayahs: 40
    },
    {
        n: 76,
        ar: "الإنسان",
        fr: "Al-Insan",
        juz: 29,
        ayahs: 31
    },
    {
        n: 77,
        ar: "المرسلات",
        fr: "Al-Mursalat",
        juz: 29,
        ayahs: 50
    },
    {
        n: 78,
        ar: "النبأ",
        fr: "An-Naba",
        juz: 30,
        ayahs: 40
    },
    {
        n: 79,
        ar: "النازعات",
        fr: "An-Nazi'at",
        juz: 30,
        ayahs: 46
    },
    {
        n: 80,
        ar: "عبس",
        fr: "Abasa",
        juz: 30,
        ayahs: 42
    },
    {
        n: 81,
        ar: "التكوير",
        fr: "At-Takwir",
        juz: 30,
        ayahs: 29
    },
    {
        n: 82,
        ar: "الانفطار",
        fr: "Al-Infitar",
        juz: 30,
        ayahs: 19
    },
    {
        n: 83,
        ar: "المطففين",
        fr: "Al-Mutaffifin",
        juz: 30,
        ayahs: 36
    },
    {
        n: 84,
        ar: "الانشقاق",
        fr: "Al-Inshiqaq",
        juz: 30,
        ayahs: 25
    },
    {
        n: 85,
        ar: "البروج",
        fr: "Al-Buruj",
        juz: 30,
        ayahs: 22
    },
    {
        n: 86,
        ar: "الطارق",
        fr: "At-Tariq",
        juz: 30,
        ayahs: 17
    },
    {
        n: 87,
        ar: "الأعلى",
        fr: "Al-Ala",
        juz: 30,
        ayahs: 19
    },
    {
        n: 88,
        ar: "الغاشية",
        fr: "Al-Ghashiya",
        juz: 30,
        ayahs: 26
    },
    {
        n: 89,
        ar: "الفجر",
        fr: "Al-Fajr",
        juz: 30,
        ayahs: 30
    },
    {
        n: 90,
        ar: "البلد",
        fr: "Al-Balad",
        juz: 30,
        ayahs: 20
    },
    {
        n: 91,
        ar: "الشمس",
        fr: "Ash-Shams",
        juz: 30,
        ayahs: 15
    },
    {
        n: 92,
        ar: "الليل",
        fr: "Al-Layl",
        juz: 30,
        ayahs: 21
    },
    {
        n: 93,
        ar: "الضحى",
        fr: "Ad-Duha",
        juz: 30,
        ayahs: 11
    },
    {
        n: 94,
        ar: "الشرح",
        fr: "Ash-Sharh",
        juz: 30,
        ayahs: 8
    },
    {
        n: 95,
        ar: "التين",
        fr: "At-Tin",
        juz: 30,
        ayahs: 8
    },
    {
        n: 96,
        ar: "العلق",
        fr: "Al-Alaq",
        juz: 30,
        ayahs: 19
    },
    {
        n: 97,
        ar: "القدر",
        fr: "Al-Qadr",
        juz: 30,
        ayahs: 5
    },
    {
        n: 98,
        ar: "البينة",
        fr: "Al-Bayyina",
        juz: 30,
        ayahs: 8
    },
    {
        n: 99,
        ar: "الزلزلة",
        fr: "Az-Zalzala",
        juz: 30,
        ayahs: 8
    },
    {
        n: 100,
        ar: "العاديات",
        fr: "Al-Adiyat",
        juz: 30,
        ayahs: 11
    },
    {
        n: 101,
        ar: "القارعة",
        fr: "Al-Qari'a",
        juz: 30,
        ayahs: 11
    },
    {
        n: 102,
        ar: "التكاثر",
        fr: "At-Takathur",
        juz: 30,
        ayahs: 8
    },
    {
        n: 103,
        ar: "العصر",
        fr: "Al-Asr",
        juz: 30,
        ayahs: 3
    },
    {
        n: 104,
        ar: "الهمزة",
        fr: "Al-Humaza",
        juz: 30,
        ayahs: 9
    },
    {
        n: 105,
        ar: "الفيل",
        fr: "Al-Fil",
        juz: 30,
        ayahs: 5
    },
    {
        n: 106,
        ar: "قريش",
        fr: "Quraysh",
        juz: 30,
        ayahs: 4
    },
    {
        n: 107,
        ar: "الماعون",
        fr: "Al-Ma'un",
        juz: 30,
        ayahs: 7
    },
    {
        n: 108,
        ar: "الكوثر",
        fr: "Al-Kawthar",
        juz: 30,
        ayahs: 3
    },
    {
        n: 109,
        ar: "الكافرون",
        fr: "Al-Kafirun",
        juz: 30,
        ayahs: 6
    },
    {
        n: 110,
        ar: "النصر",
        fr: "An-Nasr",
        juz: 30,
        ayahs: 3
    },
    {
        n: 111,
        ar: "المسد",
        fr: "Al-Masad",
        juz: 30,
        ayahs: 5
    },
    {
        n: 112,
        ar: "الإخلاص",
        fr: "Al-Ikhlas",
        juz: 30,
        ayahs: 4
    },
    {
        n: 113,
        ar: "الفلق",
        fr: "Al-Falaq",
        juz: 30,
        ayahs: 5
    },
    {
        n: 114,
        ar: "الناس",
        fr: "An-Nas",
        juz: 30,
        ayahs: 6
    }
];
const JUZ_SURAHS = Array.from({
    length: 30
}, (_, i)=>SURAHS.filter((s)=>s.juz === i + 1));
function countMemorized(memo) {
    return Object.values(memo).filter((s)=>s === "memorized").length;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MemoMap.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MemoMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.mjs [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$quran$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/quran.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const STATUS_CYCLE = [
    "not_started",
    "in_progress",
    "memorized",
    "needs_revision"
];
const STATUS_CLS = {
    not_started: "bg-gray-100 text-gray-400 border-gray-200",
    in_progress: "bg-amber-50 text-amber-700 border-amber-300",
    memorized: "bg-emerald-50 text-emerald-700 border-emerald-300",
    needs_revision: "bg-red-50 text-red-600 border-red-300"
};
const JUZ_BAR_CLS = {
    not_started: "bg-gray-200",
    in_progress: "bg-amber-400",
    memorized: "bg-emerald-500",
    needs_revision: "bg-red-400"
};
const tMap = {
    ar: {
        juz: (n)=>`الجزء ${n}`,
        total: (n)=>`${n} / 114 سورة محفوظة`,
        legend: "المفتاح",
        statuses: {
            not_started: "لم يبدأ",
            in_progress: "جارٍ الحفظ",
            memorized: "محفوظ",
            needs_revision: "يحتاج مراجعة"
        },
        clickHint: "انقر على السورة لتغيير حالتها"
    },
    fr: {
        juz: (n)=>`Juz ${n}`,
        total: (n)=>`${n} / 114 sourates mémorisées`,
        legend: "Légende",
        statuses: {
            not_started: "Non commencé",
            in_progress: "En cours",
            memorized: "Mémorisé",
            needs_revision: "À réviser"
        },
        clickHint: "Cliquez sur une sourate pour changer son état"
    }
};
function getStatus(memo, n) {
    return memo[n] ?? "not_started";
}
function MemoMap({ value, editable = false, onChange, lang }) {
    _s();
    const T = tMap[lang];
    const [openJuz, setOpenJuz] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        30
    ]);
    const memorizedCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$quran$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["countMemorized"])(value);
    const totalPct = Math.round(memorizedCount / 114 * 100);
    function cycleStatus(n) {
        if (!editable || !onChange) return;
        const cur = getStatus(value, n);
        const next = STATUS_CYCLE[(STATUS_CYCLE.indexOf(cur) + 1) % STATUS_CYCLE.length];
        onChange({
            ...value,
            [n]: next
        });
    }
    function toggleJuz(juzNum) {
        setOpenJuz((prev)=>prev.includes(juzNum) ? prev.filter((j)=>j !== juzNum) : [
                ...prev,
                juzNum
            ]);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        dir: lang === "ar" ? "rtl" : "ltr",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row sm:items-center gap-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs font-semibold text-[#2d6a4f]",
                                    children: T.total(memorizedCount)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MemoMap.tsx",
                                    lineNumber: 86,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-[#aaa]",
                                    children: [
                                        totalPct,
                                        "%"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/MemoMap.tsx",
                                    lineNumber: 87,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MemoMap.tsx",
                            lineNumber: 85,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full h-2.5 bg-gray-100 rounded-full overflow-hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-full bg-emerald-500 rounded-full transition-all duration-500",
                                style: {
                                    width: `${totalPct}%`
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/MemoMap.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/MemoMap.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MemoMap.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 items-center text-xs",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#aaa] font-semibold",
                        children: [
                            T.legend,
                            " :"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/MemoMap.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this),
                    [
                        "not_started",
                        "in_progress",
                        "memorized",
                        "needs_revision"
                    ].map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `px-2 py-0.5 rounded-full border font-medium ${STATUS_CLS[s]}`,
                            children: T.statuses[s]
                        }, s, false, {
                            fileName: "[project]/src/components/MemoMap.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[10px] text-[#bbb] italic",
                children: T.clickHint
            }, void 0, false, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 108,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$quran$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JUZ_SURAHS"].map((surahs, idx)=>{
                    const juzNum = idx + 1;
                    const isOpen = openJuz.includes(juzNum);
                    const juzMemo = surahs.filter((s)=>getStatus(value, s.n) === "memorized").length;
                    const juzPct = Math.round(juzMemo / surahs.length * 100);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border border-[#e8dfc8] rounded-xl overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>toggleJuz(juzNum),
                                className: "w-full flex items-center justify-between px-4 py-2.5 bg-[#faf8f4] hover:bg-[#f5f0e8] transition-colors text-start",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-bold text-[#2d6a4f] shrink-0",
                                                children: T.juz(juzNum)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 125,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-24 h-1.5 bg-gray-100 rounded-full overflow-hidden shrink-0",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-full bg-emerald-400 rounded-full transition-all",
                                                            style: {
                                                                width: `${juzPct}%`
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/MemoMap.tsx",
                                                            lineNumber: 128,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/MemoMap.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] text-[#aaa] shrink-0",
                                                        children: [
                                                            juzMemo,
                                                            "/",
                                                            surahs.length
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/MemoMap.tsx",
                                                        lineNumber: 133,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 126,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/MemoMap.tsx",
                                        lineNumber: 124,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 shrink-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden sm:flex gap-0.5",
                                                children: surahs.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `w-2 h-2 rounded-sm ${JUZ_BAR_CLS[getStatus(value, s.n)]}`
                                                    }, s.n, false, {
                                                        fileName: "[project]/src/components/MemoMap.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 23
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 137,
                                                columnNumber: 19
                                            }, this),
                                            isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                size: 14,
                                                className: "text-[#bbb]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 145,
                                                columnNumber: 29
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                size: 14,
                                                className: "text-[#bbb]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 145,
                                                columnNumber: 79
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/MemoMap.tsx",
                                        lineNumber: 136,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/MemoMap.tsx",
                                lineNumber: 120,
                                columnNumber: 15
                            }, this),
                            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-1.5",
                                children: surahs.map((s)=>{
                                    const status = getStatus(value, s.n);
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>cycleStatus(s.n),
                                        disabled: !editable,
                                        className: `rounded-lg border px-2 py-1.5 text-center transition-colors ${STATUS_CLS[status]} ${editable ? "hover:opacity-75 cursor-pointer" : "cursor-default"}`,
                                        title: `${lang === "ar" ? s.ar : s.fr} — ${T.statuses[status]}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[10px] font-bold",
                                                children: s.n
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 161,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[10px] leading-tight mt-0.5 truncate",
                                                children: lang === "ar" ? s.ar : s.fr
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 162,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[9px] opacity-60 mt-0.5",
                                                children: [
                                                    s.ayahs,
                                                    "v"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 165,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, s.n, true, {
                                        fileName: "[project]/src/components/MemoMap.tsx",
                                        lineNumber: 154,
                                        columnNumber: 23
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/MemoMap.tsx",
                                lineNumber: 150,
                                columnNumber: 17
                            }, this)
                        ]
                    }, juzNum, true, {
                        fileName: "[project]/src/components/MemoMap.tsx",
                        lineNumber: 119,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/MemoMap.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
_s(MemoMap, "YKqDgzfwvb48xy1AzEqsH+abTq0=");
_c = MemoMap;
var _c;
__turbopack_context__.k.register(_c, "MemoMap");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/dashboard/professor/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProfessorDashboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-open.mjs [app-client] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.mjs [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.mjs [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.mjs [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/users.mjs [app-client] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/graduation-cap.mjs [app-client] (ecmascript) <export default as GraduationCap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.mjs [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check-big.mjs [app-client] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/pencil.mjs [app-client] (ecmascript) <export default as Pencil>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.mjs [app-client] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.mjs [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.mjs [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trophy.mjs [app-client] (ecmascript) <export default as Trophy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.mjs [app-client] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clipboard-list.mjs [app-client] (ecmascript) <export default as ClipboardList>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MemoMap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MemoMap.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
const t = {
    ar: {
        schoolName: "نور القرآن",
        professor: "أستاذ",
        logout: "تسجيل الخروج",
        tabStudents: "الطلاب",
        tabProfessors: "الأساتذة",
        tabTop3: "أفضل 3",
        tabAnnouncements: "الإعلانات",
        toastSession: "تم تسجيل الحصة بنجاح.",
        toastStudent: "تم إضافة الطالب بنجاح.",
        toastProf: "تم إضافة الأستاذ بنجاح.",
        toastDeleted: "تم الحذف بنجاح.",
        toastEdited: "تم تعديل بيانات الطالب بنجاح.",
        toastTop3: "تم حفظ أفضل 3 طلاب للأسبوع.",
        toastAnnouncement: "تم إضافة الإعلان بنجاح.",
        toastMemo: "تم حفظ خريطة الحفظ بنجاح.",
        errRequired: "يرجى ملء جميع الحقول الإلزامية.",
        errEmail: "هذا البريد الإلكتروني مستخدم بالفعل.",
        confirmDelete: "هل أنت متأكد من الحذف؟",
        confirmYes: "نعم، احذف",
        searchPh: "البحث عن طالب...",
        addStudent: "إضافة طالب",
        newStudent: "طالب جديد",
        editTitle: "تعديل بيانات الطالب",
        editLabel: "تعديل",
        deleteLabel: "حذف",
        fieldName: "الاسم الكامل *",
        fieldAge: "العمر",
        fieldLevel: "المستوى",
        fieldParentName: "اسم ولي الأمر *",
        fieldParentEmail: "البريد الإلكتروني لولي الأمر *",
        parentHint: "إذا لم يكن لولي الأمر حساب، سيتم إنشاؤه تلقائياً (كلمة المرور الافتراضية: parent123).",
        photoUpload: "صورة الطالب",
        save: "حفظ",
        cancel: "إلغاء",
        noStudents: "لم يُعثر على طالب.",
        parentLabel: "ولي الأمر:",
        sessions: (n)=>`${n} حصة`,
        attendanceLabel: "الحضور:",
        innerTabSessions: "الحصص",
        innerTabMemo: "خريطة الحفظ",
        sessionHistory: "سجل الحصص",
        noSessions: "لم يتم تسجيل أي حصة.",
        colDate: "التاريخ",
        colAttendance: "الحضور",
        colDiscipline: "الانضباط",
        colMemo: "الحفظ",
        colComment: "الملاحظة",
        present: "حاضر",
        absent: "غائب",
        newSession: "حصة جديدة",
        fieldDate: "التاريخ",
        fieldPresence: "الحضور",
        fieldDiscipline: "الانضباط",
        fieldMemo: "الحفظ / المراجعة",
        memoPh: "مثال: الفاتحة (1-7)",
        fieldComment: "ملاحظة الأستاذ",
        commentPh: "الملاحظات، نقاط التحسين...",
        saveSession: "تسجيل الحصة",
        addSession: "إضافة حصة",
        memoSave: "حفظ التقدم",
        addProf: "إضافة أستاذ",
        newProf: "أستاذ جديد",
        fieldEmail: "البريد الإلكتروني *",
        fieldPassword: "كلمة المرور *",
        fieldSpecialty: "التخصص",
        specialtyPh: "التجويد، الحفظ، اللغة العربية...",
        yourAccount: "حسابك",
        ageSuffix: "سنة",
        prevPage: "السابق",
        nextPage: "التالي",
        top3Title: "أفضل 3 طلاب للأسبوع",
        rank1: "المركز الأول 🥇",
        rank2: "المركز الثاني 🥈",
        rank3: "المركز الثالث 🥉",
        top3Save: "حفظ الاختيار",
        top3None: "— لا أحد —",
        annTitle: "لوحة الإعلانات",
        addAnnouncement: "إضافة إعلان",
        newAnnouncement: "إعلان جديد",
        annFieldTitle: "عنوان الإعلان *",
        annFieldBody: "تفاصيل الإعلان",
        annFieldImage: "صورة (اختياري)",
        annBodyPh: "وصف الحدث، التفاصيل...",
        noAnnouncements: "لا توجد إعلانات بعد.",
        tabExams: "الاختبارات",
        createExam: "إنشاء اختبار",
        newExam: "اختبار جديد",
        examFieldTitle: "عنوان الاختبار *",
        addQuestion: "إضافة سؤال",
        questionLabel: (n)=>`السؤال ${n}`,
        questionPh: "نص السؤال...",
        optionLabel: (l)=>`الخيار ${l}`,
        optionPh: "نص الخيار...",
        correctAnswer: "الإجابة الصحيحة",
        removeQuestion: "حذف",
        toastExam: "تم إنشاء الاختبار بنجاح.",
        noExams: "لم يتم إنشاء أي اختبار بعد.",
        questionsCount: (n)=>`${n} سؤال`,
        examResults: "نتائج الاختبار",
        noResults: "لم يؤدِّ أحد هذا الاختبار بعد.",
        resultStudent: "الطالب",
        resultScore: "النتيجة",
        resultDate: "التاريخ",
        errNoQuestions: "يرجى إضافة سؤال واحد على الأقل.",
        errQuestionEmpty: "يرجى ملء نص جميع الأسئلة.",
        errOptionEmpty: "يرجى ملء جميع خيارات الأسئلة.",
        createdBy: "الأستاذ:",
        disciplines: {
            excellent: "ممتاز",
            bon: "جيد",
            passable: "مقبول",
            insuffisant: "ضعيف"
        },
        levels: {
            "Débutant": "مبتدئ",
            "Intermédiaire": "متوسط",
            "Avancé": "متقدم",
            "Hifz": "حفظ"
        }
    },
    fr: {
        schoolName: "Nur Al-Quran",
        professor: "Professeur",
        logout: "Déconnexion",
        tabStudents: "Élèves",
        tabProfessors: "Professeurs",
        tabTop3: "Top 3",
        tabAnnouncements: "Annonces",
        toastSession: "Séance enregistrée avec succès.",
        toastStudent: "Élève ajouté avec succès.",
        toastProf: "Professeur ajouté avec succès.",
        toastDeleted: "Supprimé avec succès.",
        toastEdited: "Informations modifiées avec succès.",
        toastTop3: "Top 3 de la semaine enregistré.",
        toastAnnouncement: "Annonce ajoutée avec succès.",
        toastMemo: "Carte de mémorisation enregistrée.",
        errRequired: "Veuillez remplir tous les champs obligatoires.",
        errEmail: "Cet email est déjà utilisé.",
        confirmDelete: "Confirmer la suppression ?",
        confirmYes: "Oui, supprimer",
        searchPh: "Rechercher un élève...",
        addStudent: "Ajouter un élève",
        newStudent: "Nouvel élève",
        editTitle: "Modifier les informations",
        editLabel: "Modifier",
        deleteLabel: "Supprimer",
        fieldName: "Nom complet *",
        fieldAge: "Âge",
        fieldLevel: "Niveau",
        fieldParentName: "Nom du parent *",
        fieldParentEmail: "Email du parent *",
        parentHint: "Si ce parent n'a pas encore de compte, un compte sera créé automatiquement (mot de passe par défaut : parent123).",
        photoUpload: "Photo de l'élève",
        save: "Enregistrer",
        cancel: "Annuler",
        noStudents: "Aucun élève trouvé.",
        parentLabel: "Parent :",
        sessions: (n)=>`${n} séance${n !== 1 ? "s" : ""}`,
        attendanceLabel: "Présence :",
        innerTabSessions: "Séances",
        innerTabMemo: "Carte de mémorisation",
        sessionHistory: "Historique des séances",
        noSessions: "Aucune séance enregistrée.",
        colDate: "Date",
        colAttendance: "Présence",
        colDiscipline: "Discipline",
        colMemo: "Mémorisation",
        colComment: "Commentaire",
        present: "Présent",
        absent: "Absent",
        newSession: "Nouvelle séance",
        fieldDate: "Date",
        fieldPresence: "Présence",
        fieldDiscipline: "Discipline",
        fieldMemo: "Mémorisation / Révision",
        memoPh: "Ex : Al-Fatiha (1-7)",
        fieldComment: "Commentaire du professeur",
        commentPh: "Observations, points à améliorer...",
        saveSession: "Enregistrer la séance",
        addSession: "Ajouter une séance",
        memoSave: "Enregistrer la progression",
        addProf: "Ajouter un professeur",
        newProf: "Nouveau professeur",
        fieldEmail: "Email *",
        fieldPassword: "Mot de passe *",
        fieldSpecialty: "Spécialité",
        specialtyPh: "Tajweed, Hifz, Langue Arabe...",
        yourAccount: "Votre compte",
        ageSuffix: "ans",
        prevPage: "Précédent",
        nextPage: "Suivant",
        top3Title: "Top 3 élèves de la semaine",
        rank1: "1ère place 🥇",
        rank2: "2ème place 🥈",
        rank3: "3ème place 🥉",
        top3Save: "Enregistrer le choix",
        top3None: "— Aucun —",
        annTitle: "Tableau des annonces",
        addAnnouncement: "Ajouter une annonce",
        newAnnouncement: "Nouvelle annonce",
        annFieldTitle: "Titre de l'annonce *",
        annFieldBody: "Détails de l'annonce",
        annFieldImage: "Image (facultatif)",
        annBodyPh: "Description de l'événement, détails...",
        noAnnouncements: "Aucune annonce pour le moment.",
        tabExams: "Examens",
        createExam: "Créer un examen",
        newExam: "Nouvel examen",
        examFieldTitle: "Titre de l'examen *",
        addQuestion: "Ajouter une question",
        questionLabel: (n)=>`Question ${n}`,
        questionPh: "Texte de la question...",
        optionLabel: (l)=>`Option ${l}`,
        optionPh: "Texte de l'option...",
        correctAnswer: "Bonne réponse",
        removeQuestion: "Supprimer",
        toastExam: "Examen créé avec succès.",
        noExams: "Aucun examen créé pour le moment.",
        questionsCount: (n)=>`${n} question${n !== 1 ? "s" : ""}`,
        examResults: "Résultats de l'examen",
        noResults: "Aucun élève n'a passé cet examen.",
        resultStudent: "Élève",
        resultScore: "Score",
        resultDate: "Date",
        errNoQuestions: "Veuillez ajouter au moins une question.",
        errQuestionEmpty: "Veuillez remplir le texte de toutes les questions.",
        errOptionEmpty: "Veuillez remplir tous les choix de réponse.",
        createdBy: "Professeur :",
        disciplines: {
            excellent: "Excellent",
            bon: "Bon",
            passable: "Passable",
            insuffisant: "Insuffisant"
        },
        levels: {
            "Débutant": "Débutant",
            "Intermédiaire": "Intermédiaire",
            "Avancé": "Avancé",
            "Hifz": "Hifz"
        }
    }
};
const DISC_CLS = {
    excellent: "text-emerald-700 bg-emerald-50 border-emerald-200",
    bon: "text-blue-700 bg-blue-50 border-blue-200",
    passable: "text-amber-700 bg-amber-50 border-amber-200",
    insuffisant: "text-red-700 bg-red-50 border-red-200"
};
const LEVELS = [
    "Débutant",
    "Intermédiaire",
    "Avancé",
    "Hifz"
];
const PAGE_SIZE = 8;
const INPUT = "w-full px-3.5 py-2.5 rounded-xl border border-[#e8dfc8] bg-white text-sm placeholder-[#bbb] focus:outline-none focus:border-[#2d6a4f] focus:ring-2 focus:ring-[#2d6a4f]/10 transition-all";
const LABEL = "block text-xs font-semibold text-[#555] uppercase tracking-wider mb-1.5";
async function resizeToBase64(file) {
    return new Promise((resolve)=>{
        const img = new Image();
        const url = URL.createObjectURL(file);
        img.onload = ()=>{
            const canvas = document.createElement("canvas");
            canvas.width = 200;
            canvas.height = 200;
            const ctx = canvas.getContext("2d");
            const size = Math.min(img.width, img.height);
            ctx.drawImage(img, (img.width - size) / 2, (img.height - size) / 2, size, size, 0, 0, 200, 200);
            URL.revokeObjectURL(url);
            resolve(canvas.toDataURL("image/jpeg", 0.7));
        };
        img.src = url;
    });
}
async function resizeAnnImage(file) {
    return new Promise((resolve)=>{
        const img = new Image();
        const url = URL.createObjectURL(file);
        img.onload = ()=>{
            const canvas = document.createElement("canvas");
            const maxW = 800;
            const ratio = Math.min(maxW / img.width, 1);
            canvas.width = Math.round(img.width * ratio);
            canvas.height = Math.round(img.height * ratio);
            canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
            URL.revokeObjectURL(url);
            resolve(canvas.toDataURL("image/jpeg", 0.8));
        };
        img.src = url;
    });
}
function attendanceRate(sessions) {
    if (!sessions.length) return "—";
    return `${Math.round(sessions.filter((s)=>s.present).length / sessions.length * 100)}%`;
}
function initials(name) {
    return name.split(" ").map((w)=>w[0]).join("").slice(0, 2).toUpperCase();
}
const emptySession = ()=>({
        date: new Date().toISOString().split("T")[0],
        present: true,
        discipline: "bon",
        memorization: "",
        comment: ""
    });
const emptyStudent = ()=>({
        name: "",
        age: "",
        level: "Débutant",
        parentEmail: "",
        parentName: "",
        photo: ""
    });
const emptyProf = ()=>({
        name: "",
        email: "",
        password: "",
        specialty: ""
    });
const emptyAnn = ()=>({
        title: "",
        body: "",
        image: ""
    });
const OPTION_LABELS = [
    "A",
    "B",
    "C",
    "D"
];
function emptyQuestion() {
    return {
        id: `q_${Date.now()}_${Math.random().toString(36).slice(2)}`,
        text: "",
        options: OPTION_LABELS.map((l)=>({
                id: l.toLowerCase(),
                text: ""
            })),
        correctOptionId: "a"
    };
}
function emptyExamDraft() {
    return {
        title: "",
        questions: [
            emptyQuestion()
        ]
    };
}
function scoreColor(score) {
    if (score >= 70) return "text-emerald-700 bg-emerald-50 border-emerald-200";
    if (score >= 50) return "text-amber-700 bg-amber-50 border-amber-200";
    return "text-red-700 bg-red-50 border-red-200";
}
function ProfessorDashboard() {
    _s();
    const { user, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { lang, dir, setLang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const T = t[lang];
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [students, setStudents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [profiles, setProfiles] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [topStudents, setTopStudents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [topForm, setTopForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        r1: "",
        r2: "",
        r3: ""
    });
    const [announcements, setAnnouncements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [tab, setTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("students");
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [expandedId, setExpandedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [innerTab, setInnerTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("sessions");
    const [memoEdit, setMemoEdit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [showNewSession, setShowNewSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [showAddStudent, setShowAddStudent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showAddProf, setShowAddProf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showAddAnn, setShowAddAnn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [sessionForm, setSessionForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(emptySession());
    const [studentForm, setStudentForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(emptyStudent());
    const [profForm, setProfForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(emptyProf());
    const [annForm, setAnnForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(emptyAnn());
    const [studentErr, setStudentErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [profErr, setProfErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [annErr, setAnnErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [toast, setToast] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [editingStudentId, setEditingStudentId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editForm, setEditForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: "",
        age: "",
        level: "Débutant",
        photo: ""
    });
    const [deletingStudentId, setDeletingStudentId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deletingProfId, setDeletingProfId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deletingAnnId, setDeletingAnnId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [exams, setExams] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [examResults, setExamResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [showCreateExam, setShowCreateExam] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [examForm, setExamForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(emptyExamDraft());
    const [examErr, setExamErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [expandedExamId, setExpandedExamId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deletingExamId, setDeletingExamId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfessorDashboard.useEffect": ()=>{
            if (!user) {
                router.push("/login");
                return;
            }
            if (user.role !== "professor") {
                router.push("/login");
                return;
            }
            ({
                "ProfessorDashboard.useEffect": async ()=>{
                    const [studs, profs, anns, exs, results, tops] = await Promise.all([
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStudents"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProfiles"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAnnouncements"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExams"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExamResults"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTopStudents"])()
                    ]);
                    setStudents(studs);
                    setProfiles(profs);
                    setAnnouncements(anns);
                    setExams(exs);
                    setExamResults(results);
                    setTopStudents(tops);
                    const form = {
                        r1: "",
                        r2: "",
                        r3: ""
                    };
                    tops.forEach({
                        "ProfessorDashboard.useEffect": (e)=>{
                            if (e.rank === 1) form.r1 = e.studentId;
                            else if (e.rank === 2) form.r2 = e.studentId;
                            else if (e.rank === 3) form.r3 = e.studentId;
                        }
                    }["ProfessorDashboard.useEffect"]);
                    setTopForm(form);
                }
            })["ProfessorDashboard.useEffect"]();
        }
    }["ProfessorDashboard.useEffect"], [
        user,
        router
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfessorDashboard.useEffect": ()=>{
            setPage(0);
        }
    }["ProfessorDashboard.useEffect"], [
        search
    ]);
    async function refresh() {
        const [studs, profs] = await Promise.all([
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStudents"])(),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProfiles"])()
        ]);
        setStudents(studs);
        setProfiles(profs);
    }
    function flash(msg) {
        setToast(msg);
        setTimeout(()=>setToast(""), 3500);
    }
    function expandStudent(id) {
        const opening = expandedId !== id;
        setExpandedId(opening ? id : null);
        setInnerTab("sessions");
        setShowNewSession(null);
        if (editingStudentId) setEditingStudentId(null);
    }
    async function handleAddSession(studentId) {
        setSubmitting(true);
        const newSession = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addSession"])(studentId, user.id, sessionForm);
        setStudents((prev)=>prev.map((s)=>s.id !== studentId ? s : {
                    ...s,
                    sessions: [
                        newSession,
                        ...s.sessions
                    ]
                }));
        setShowNewSession(null);
        setSessionForm(emptySession());
        flash(T.toastSession);
        setSubmitting(false);
    }
    async function handleAddStudent() {
        setStudentErr("");
        const { name, parentEmail, parentName } = studentForm;
        if (!name.trim() || !parentEmail.trim() || !parentName.trim()) {
            setStudentErr(T.errRequired);
            return;
        }
        setSubmitting(true);
        try {
            let parent = profiles.find((u)=>u.email === parentEmail && u.role === "parent");
            if (!parent) {
                parent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUser"])(parentEmail, "parent123", parentName, "parent");
                setProfiles((prev)=>[
                        ...prev,
                        parent
                    ]);
            }
            const newStudent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addStudent"])(name, Number(studentForm.age) || 0, studentForm.level, parent.id, studentForm.photo || undefined);
            setStudents((prev)=>[
                    ...prev,
                    newStudent
                ]);
            setStudentForm(emptyStudent());
            setShowAddStudent(false);
            flash(T.toastStudent);
        } catch  {
            setStudentErr(T.errEmail);
        }
        setSubmitting(false);
    }
    async function handleEditStudent() {
        if (!editingStudentId) return;
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateStudent"])(editingStudentId, {
            name: editForm.name,
            age: Number(editForm.age) || 0,
            level: editForm.level,
            photo: editForm.photo || null
        });
        setStudents((prev)=>prev.map((s)=>s.id !== editingStudentId ? s : {
                    ...s,
                    name: editForm.name,
                    age: Number(editForm.age) || 0,
                    level: editForm.level,
                    photo: editForm.photo || undefined
                }));
        setEditingStudentId(null);
        flash(T.toastEdited);
        setSubmitting(false);
    }
    async function handleDeleteStudent(id) {
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteStudent"])(id);
        setStudents((prev)=>prev.filter((s)=>s.id !== id));
        setDeletingStudentId(null);
        if (expandedId === id) setExpandedId(null);
        if (editingStudentId === id) setEditingStudentId(null);
        flash(T.toastDeleted);
        setSubmitting(false);
    }
    async function handleSaveMemo(studentId) {
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveMemoMap"])(studentId, memoEdit);
        setStudents((prev)=>prev.map((s)=>s.id !== studentId ? s : {
                    ...s,
                    memorization: memoEdit
                }));
        flash(T.toastMemo);
        setSubmitting(false);
    }
    async function handleAddProf() {
        setProfErr("");
        const { name, email, password } = profForm;
        if (!name.trim() || !email.trim() || !password.trim()) {
            setProfErr(T.errRequired);
            return;
        }
        if (profiles.find((u)=>u.email === email)) {
            setProfErr(T.errEmail);
            return;
        }
        setSubmitting(true);
        try {
            const newProf = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createUser"])(email, password, name, "professor", profForm.specialty || undefined);
            setProfiles((prev)=>[
                    ...prev,
                    newProf
                ]);
            setProfForm(emptyProf());
            setShowAddProf(false);
            flash(T.toastProf);
        } catch  {
            setProfErr(T.errEmail);
        }
        setSubmitting(false);
    }
    async function handleDeleteProf(id) {
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteProfile"])(id);
        setProfiles((prev)=>prev.filter((u)=>u.id !== id));
        setDeletingProfId(null);
        flash(T.toastDeleted);
        setSubmitting(false);
    }
    async function handleAddAnnouncement() {
        setAnnErr("");
        if (!annForm.title.trim()) {
            setAnnErr(T.errRequired);
            return;
        }
        setSubmitting(true);
        const newAnn = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addAnnouncement"])({
            title: annForm.title,
            body: annForm.body,
            image: annForm.image || undefined,
            date: new Date().toISOString().split("T")[0]
        });
        setAnnouncements((prev)=>[
                newAnn,
                ...prev
            ]);
        setAnnForm(emptyAnn());
        setShowAddAnn(false);
        flash(T.toastAnnouncement);
        setSubmitting(false);
    }
    async function handleDeleteAnnouncement(id) {
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteAnnouncement"])(id);
        setAnnouncements((prev)=>prev.filter((a)=>a.id !== id));
        setDeletingAnnId(null);
        flash(T.toastDeleted);
        setSubmitting(false);
    }
    async function handleSaveExam() {
        setExamErr("");
        if (!examForm.title.trim()) {
            setExamErr(T.errRequired);
            return;
        }
        if (examForm.questions.length === 0) {
            setExamErr(T.errNoQuestions);
            return;
        }
        if (examForm.questions.some((q)=>!q.text.trim())) {
            setExamErr(T.errQuestionEmpty);
            return;
        }
        if (examForm.questions.some((q)=>q.options.some((o)=>!o.text.trim()))) {
            setExamErr(T.errOptionEmpty);
            return;
        }
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addExam"])({
            title: examForm.title,
            professorId: user.id,
            date: new Date().toISOString().split("T")[0],
            questions: examForm.questions
        });
        const updatedExams = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExams"])();
        setExams(updatedExams);
        setExamForm(emptyExamDraft());
        setShowCreateExam(false);
        flash(T.toastExam);
        setSubmitting(false);
    }
    async function handleDeleteExam(id) {
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExamResults"])(id);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteExam"])(id);
        setExams((prev)=>prev.filter((e)=>e.id !== id));
        setExamResults((prev)=>prev.filter((r)=>r.examId !== id));
        setDeletingExamId(null);
        if (expandedExamId === id) setExpandedExamId(null);
        flash(T.toastDeleted);
        setSubmitting(false);
    }
    async function handleSaveTop3() {
        const entries = [];
        if (topForm.r1) entries.push({
            rank: 1,
            studentId: topForm.r1
        });
        if (topForm.r2) entries.push({
            rank: 2,
            studentId: topForm.r2
        });
        if (topForm.r3) entries.push({
            rank: 3,
            studentId: topForm.r3
        });
        setSubmitting(true);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveTopStudents"])(entries);
        setTopStudents(entries);
        flash(T.toastTop3);
        setSubmitting(false);
    }
    const professors = profiles.filter((u)=>u.role === "professor");
    const filtered = students.filter((s)=>s.name.toLowerCase().includes(search.toLowerCase()));
    const pageCount = Math.ceil(filtered.length / PAGE_SIZE);
    const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
    const getParentName = (parentId)=>profiles.find((u)=>u.id === parentId)?.name ?? "—";
    if (!user) return null;
    const tabConfig = [
        {
            key: "students",
            label: T.tabStudents,
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                size: 14
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 590,
                columnNumber: 71
            }, this),
            count: students.length
        },
        {
            key: "professors",
            label: T.tabProfessors,
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__["GraduationCap"], {
                size: 14
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 591,
                columnNumber: 71
            }, this),
            count: professors.length
        },
        {
            key: "top3",
            label: T.tabTop3,
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"], {
                size: 14
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 592,
                columnNumber: 71
            }, this),
            count: topStudents.length
        },
        {
            key: "announcements",
            label: T.tabAnnouncements,
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                size: 14
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 593,
                columnNumber: 71
            }, this),
            count: announcements.length
        },
        {
            key: "exams",
            label: T.tabExams,
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__["ClipboardList"], {
                size: 14
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 594,
                columnNumber: 71
            }, this),
            count: exams.length
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-[#f5f0e8]",
        dir: dir,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "bg-white border-b border-[#e8dfc8] sticky top-0 z-30 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto px-4 lg:px-8 py-3.5 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            className: "flex items-center gap-2.5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 rounded-full bg-[#2d6a4f] flex items-center justify-center shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                                        size: 15,
                                        className: "text-[#c9a84c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 603,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                    lineNumber: 602,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-bold text-[#2d6a4f] text-base hidden sm:block",
                                    children: T.schoolName
                                }, void 0, false, {
                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                    lineNumber: 605,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                            lineNumber: 601,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setLang(lang === "ar" ? "fr" : "ar"),
                                    className: "px-2.5 py-1.5 rounded-lg border border-[#e8dfc8] text-xs font-semibold text-[#555] hover:bg-[#f5f0e8] transition-colors",
                                    children: lang === "ar" ? "FR" : "عر"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                    lineNumber: 608,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden sm:block text-end",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-semibold text-[#1a1a1a]",
                                            children: user.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 612,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-xs text-[#c9a84c]",
                                            children: user.specialty ?? T.professor
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 613,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                    lineNumber: 611,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        logout();
                                        router.push("/");
                                    },
                                    className: "flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm text-[#888] hover:text-red-600 hover:bg-red-50 transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                                            size: 15
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 616,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "hidden sm:inline",
                                            children: T.logout
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 617,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                    lineNumber: 615,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                            lineNumber: 607,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                    lineNumber: 600,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 599,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "max-w-7xl mx-auto px-4 lg:px-8 py-8",
                children: [
                    toast && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-5 flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm px-4 py-3 rounded-xl",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"], {
                                size: 15,
                                className: "shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 626,
                                columnNumber: 13
                            }, this),
                            toast
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 625,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-1 overflow-x-auto bg-white rounded-xl p-1 border border-[#e8dfc8] mb-6 shadow-sm [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]",
                        children: tabConfig.map(({ key, label, icon, count })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setTab(key),
                                className: `flex items-center gap-1.5 px-3 py-2 sm:px-4 rounded-lg text-xs sm:text-sm font-medium transition-colors shrink-0 ${tab === key ? "bg-[#2d6a4f] text-white shadow-sm" : "text-[#777] hover:text-[#1a1a1a]"}`,
                                children: [
                                    icon,
                                    label,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `hidden sm:inline text-xs px-1.5 py-0.5 rounded-full ${tab === key ? "bg-white/20 text-white" : "bg-[#f0ead8] text-[#888]"}`,
                                        children: count
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 635,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, key, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 632,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 630,
                        columnNumber: 9
                    }, this),
                    tab === "students" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col sm:flex-row gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                                size: 14,
                                                className: "absolute start-3.5 top-1/2 -translate-y-1/2 text-[#bbb]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 645,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                value: search,
                                                onChange: (e)=>setSearch(e.target.value),
                                                placeholder: T.searchPh,
                                                className: "w-full ps-9 pe-4 py-2.5 rounded-xl border border-[#e8dfc8] bg-white text-sm focus:outline-none focus:border-[#2d6a4f] focus:ring-2 focus:ring-[#2d6a4f]/10 transition-all shadow-sm"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 646,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 644,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setShowAddStudent(!showAddStudent);
                                            setStudentErr("");
                                        },
                                        className: "flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors whitespace-nowrap shadow-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                size: 15
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 651,
                                                columnNumber: 17
                                            }, this),
                                            T.addStudent
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 649,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 643,
                                columnNumber: 13
                            }, this),
                            showAddStudent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-2xl border border-[#e8dfc8] p-6 shadow-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mb-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-bold text-[#1a1a1a]",
                                                children: T.newStudent
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 658,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowAddStudent(false),
                                                className: "text-[#bbb] hover:text-[#555]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 659,
                                                    columnNumber: 110
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 659,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 657,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid sm:grid-cols-2 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldName
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 662,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        className: INPUT,
                                                        placeholder: "Yusuf Ahmed",
                                                        value: studentForm.name,
                                                        onChange: (e)=>setStudentForm({
                                                                ...studentForm,
                                                                name: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 662,
                                                        columnNumber: 70
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 662,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldAge
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 663,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "number",
                                                        className: INPUT,
                                                        placeholder: "10",
                                                        min: "3",
                                                        max: "99",
                                                        value: studentForm.age,
                                                        onChange: (e)=>setStudentForm({
                                                                ...studentForm,
                                                                age: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 663,
                                                        columnNumber: 69
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 663,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldLevel
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 665,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        className: INPUT,
                                                        value: studentForm.level,
                                                        onChange: (e)=>setStudentForm({
                                                                ...studentForm,
                                                                level: e.target.value
                                                            }),
                                                        children: LEVELS.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: l,
                                                                children: T.levels[l]
                                                            }, l, false, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 667,
                                                                columnNumber: 42
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 666,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 664,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldParentName
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 670,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        className: INPUT,
                                                        placeholder: "Ahmed Martin",
                                                        value: studentForm.parentName,
                                                        onChange: (e)=>setStudentForm({
                                                                ...studentForm,
                                                                parentName: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 670,
                                                        columnNumber: 76
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 670,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldParentEmail
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 672,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "email",
                                                        className: INPUT,
                                                        dir: "ltr",
                                                        placeholder: "parent@email.com",
                                                        value: studentForm.parentEmail,
                                                        onChange: (e)=>setStudentForm({
                                                                ...studentForm,
                                                                parentEmail: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 673,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[10px] text-[#bbb] mt-1.5",
                                                        children: T.parentHint
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 674,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 671,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.photoUpload
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 677,
                                                        columnNumber: 21
                                                    }, this),
                                                    studentForm.photo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: studentForm.photo,
                                                        className: "w-14 h-14 rounded-full object-cover mb-2",
                                                        alt: ""
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 678,
                                                        columnNumber: 43
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "file",
                                                        accept: "image/*",
                                                        className: "text-xs text-[#666] file:me-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-[#2d6a4f]/10 file:text-[#2d6a4f] file:font-semibold cursor-pointer",
                                                        onChange: async (e)=>{
                                                            const f = e.target.files?.[0];
                                                            if (f) setStudentForm({
                                                                ...studentForm,
                                                                photo: await resizeToBase64(f)
                                                            });
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 679,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 676,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 661,
                                        columnNumber: 17
                                    }, this),
                                    studentErr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-red-500 text-sm mt-3",
                                        children: studentErr
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 683,
                                        columnNumber: 32
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-3 mt-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleAddStudent,
                                                className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                children: T.save
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 685,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowAddStudent(false),
                                                className: "px-5 py-2.5 rounded-xl border border-[#e8dfc8] text-[#666] text-sm hover:bg-[#f5f0e8] transition-colors",
                                                children: T.cancel
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 686,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 684,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 656,
                                columnNumber: 15
                            }, this),
                            filtered.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center py-20 text-[#ccc]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                        size: 44,
                                        className: "mx-auto mb-3 opacity-40"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 692,
                                        columnNumber: 62
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm",
                                        children: T.noStudents
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 692,
                                        columnNumber: 117
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 692,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-3",
                                        children: paged.map((student)=>{
                                            const isExpanded = expandedId === student.id;
                                            const isEditing = editingStudentId === student.id;
                                            const isDeleting = deletingStudentId === student.id;
                                            const sorted = [
                                                ...student.sessions
                                            ].sort((a, b)=>b.date.localeCompare(a.date));
                                            const last = sorted[0];
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-white rounded-2xl border border-[#e8dfc8] overflow-hidden shadow-sm",
                                                children: isDeleting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-5 flex flex-wrap items-center justify-between gap-3 bg-red-50",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-sm font-medium text-red-700",
                                                            children: T.confirmDelete
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 706,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>handleDeleteStudent(student.id),
                                                                    className: "px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors",
                                                                    children: T.confirmYes
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 708,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>setDeletingStudentId(null),
                                                                    className: "px-3 py-1.5 rounded-lg border border-[#e8dfc8] text-[#666] text-xs hover:bg-white transition-colors",
                                                                    children: T.cancel
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 709,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 707,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 705,
                                                    columnNumber: 27
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            onClick: ()=>expandStudent(student.id),
                                                            className: "flex items-center justify-between p-4 sm:p-5 hover:bg-[#faf8f4] transition-colors cursor-pointer",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-3 min-w-0",
                                                                    children: [
                                                                        student.photo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                            src: student.photo,
                                                                            className: "w-10 h-10 rounded-full object-cover shrink-0",
                                                                            alt: ""
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 716,
                                                                            columnNumber: 50
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "w-10 h-10 rounded-full bg-[#2d6a4f]/10 flex items-center justify-center text-[#2d6a4f] font-bold text-xs shrink-0",
                                                                            children: initials(student.name)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 717,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "min-w-0",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "font-semibold text-[#1a1a1a] text-sm truncate",
                                                                                    children: student.name
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 720,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "text-xs text-[#aaa] mt-0.5 truncate",
                                                                                    children: [
                                                                                        T.levels[student.level] ?? student.level,
                                                                                        student.age > 0 ? ` · ${student.age} ${T.ageSuffix}` : "",
                                                                                        " · ",
                                                                                        T.parentLabel,
                                                                                        " ",
                                                                                        getParentName(student.parentId)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 721,
                                                                                    columnNumber: 35
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 719,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 715,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-1.5 shrink-0",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "hidden sm:flex items-center gap-2.5 text-xs me-1",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "text-[#aaa]",
                                                                                    children: T.sessions(student.sessions.length)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 730,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "text-[#aaa]",
                                                                                    children: "·"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 731,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "text-[#aaa]",
                                                                                    children: [
                                                                                        T.attendanceLabel,
                                                                                        " ",
                                                                                        attendanceRate(student.sessions)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 732,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                last && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: `px-2 py-0.5 rounded-full text-xs font-medium border ${DISC_CLS[last.discipline]}`,
                                                                                    children: T.disciplines[last.discipline]
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 733,
                                                                                    columnNumber: 44
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 729,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: (e)=>{
                                                                                e.stopPropagation();
                                                                                if (isEditing) {
                                                                                    setEditingStudentId(null);
                                                                                } else {
                                                                                    setEditingStudentId(student.id);
                                                                                    setExpandedId(student.id);
                                                                                    setInnerTab("sessions");
                                                                                    setShowNewSession(null);
                                                                                    setEditForm({
                                                                                        name: student.name,
                                                                                        age: String(student.age),
                                                                                        level: student.level,
                                                                                        photo: student.photo || ""
                                                                                    });
                                                                                }
                                                                            },
                                                                            className: `p-1.5 rounded-lg transition-colors ${isEditing ? "bg-[#2d6a4f]/10 text-[#2d6a4f]" : "text-[#bbb] hover:text-[#2d6a4f] hover:bg-[#2d6a4f]/10"}`,
                                                                            title: T.editLabel,
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pencil$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Pencil$3e$__["Pencil"], {
                                                                                size: 13
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 737,
                                                                                columnNumber: 35
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 735,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: (e)=>{
                                                                                e.stopPropagation();
                                                                                setDeletingStudentId(student.id);
                                                                            },
                                                                            className: "p-1.5 rounded-lg text-[#bbb] hover:text-red-500 hover:bg-red-50 transition-colors",
                                                                            title: T.deleteLabel,
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                                size: 13
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 740,
                                                                                columnNumber: 35
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 739,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                                            size: 16,
                                                                            className: "text-[#bbb]"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 742,
                                                                            columnNumber: 47
                                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                                            size: 16,
                                                                            className: "text-[#bbb]"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 742,
                                                                            columnNumber: 97
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 728,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 714,
                                                            columnNumber: 29
                                                        }, this),
                                                        isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "border-t border-[#f0ead8] p-4 sm:p-5",
                                                            children: isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                        className: "text-sm font-semibold text-[#1a1a1a] mb-4",
                                                                        children: T.editTitle
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 750,
                                                                        columnNumber: 37
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "grid sm:grid-cols-2 gap-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: LABEL,
                                                                                        children: T.fieldName
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 752,
                                                                                        columnNumber: 44
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        className: INPUT,
                                                                                        value: editForm.name,
                                                                                        onChange: (e)=>setEditForm({
                                                                                                ...editForm,
                                                                                                name: e.target.value
                                                                                            })
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 752,
                                                                                        columnNumber: 90
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 752,
                                                                                columnNumber: 39
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: LABEL,
                                                                                        children: T.fieldAge
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 753,
                                                                                        columnNumber: 44
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "number",
                                                                                        className: INPUT,
                                                                                        min: "3",
                                                                                        max: "99",
                                                                                        value: editForm.age,
                                                                                        onChange: (e)=>setEditForm({
                                                                                                ...editForm,
                                                                                                age: e.target.value
                                                                                            })
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 753,
                                                                                        columnNumber: 89
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 753,
                                                                                columnNumber: 39
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: LABEL,
                                                                                        children: T.fieldLevel
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 755,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                                        className: INPUT,
                                                                                        value: editForm.level,
                                                                                        onChange: (e)=>setEditForm({
                                                                                                ...editForm,
                                                                                                level: e.target.value
                                                                                            }),
                                                                                        children: LEVELS.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                                value: l,
                                                                                                children: T.levels[l]
                                                                                            }, l, false, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 757,
                                                                                                columnNumber: 62
                                                                                            }, this))
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 756,
                                                                                        columnNumber: 41
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 754,
                                                                                columnNumber: 39
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: LABEL,
                                                                                        children: T.photoUpload
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 761,
                                                                                        columnNumber: 41
                                                                                    }, this),
                                                                                    editForm.photo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                                        src: editForm.photo,
                                                                                        className: "w-14 h-14 rounded-full object-cover mb-2",
                                                                                        alt: ""
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 762,
                                                                                        columnNumber: 60
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "file",
                                                                                        accept: "image/*",
                                                                                        className: "text-xs text-[#666] file:me-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-[#2d6a4f]/10 file:text-[#2d6a4f] file:font-semibold cursor-pointer",
                                                                                        onChange: async (e)=>{
                                                                                            const f = e.target.files?.[0];
                                                                                            if (f) setEditForm({
                                                                                                ...editForm,
                                                                                                photo: await resizeToBase64(f)
                                                                                            });
                                                                                        }
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 763,
                                                                                        columnNumber: 41
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 760,
                                                                                columnNumber: 39
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 751,
                                                                        columnNumber: 37
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex gap-3 mt-5",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: handleEditStudent,
                                                                                className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                                                children: T.save
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 768,
                                                                                columnNumber: 39
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: ()=>setEditingStudentId(null),
                                                                                className: "px-5 py-2.5 rounded-xl border border-[#e8dfc8] text-[#666] text-sm hover:bg-[#f5f0e8] transition-colors",
                                                                                children: T.cancel
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 769,
                                                                                columnNumber: 39
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 767,
                                                                        columnNumber: 37
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 749,
                                                                columnNumber: 35
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex gap-2 mb-4",
                                                                        children: [
                                                                            "sessions",
                                                                            "memo"
                                                                        ].map((it)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: ()=>{
                                                                                    setInnerTab(it);
                                                                                    if (it === "memo") setMemoEdit(student.memorization ?? {});
                                                                                },
                                                                                className: `px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${innerTab === it ? "bg-[#2d6a4f] text-white" : "bg-[#f5f0e8] text-[#666] hover:bg-[#e8dfc8]"}`,
                                                                                children: it === "sessions" ? T.innerTabSessions : T.innerTabMemo
                                                                            }, it, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 776,
                                                                                columnNumber: 41
                                                                            }, this))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 774,
                                                                        columnNumber: 37
                                                                    }, this),
                                                                    innerTab === "sessions" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "space-y-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                className: "text-sm font-semibold text-[#1a1a1a]",
                                                                                children: T.sessionHistory
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 785,
                                                                                columnNumber: 41
                                                                            }, this),
                                                                            sorted.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-xs text-[#ccc]",
                                                                                children: T.noSessions
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 787,
                                                                                columnNumber: 43
                                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "overflow-x-auto rounded-xl border border-[#f0ead8]",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                                                                    className: "w-full text-xs",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                                                            className: "bg-[#faf8f4]",
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                                                className: "text-[#aaa] uppercase tracking-wider",
                                                                                                children: [
                                                                                                    [
                                                                                                        T.colDate,
                                                                                                        T.colAttendance,
                                                                                                        T.colDiscipline
                                                                                                    ].map((h)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                                            className: "text-start px-4 py-2.5 font-medium",
                                                                                                            children: h
                                                                                                        }, h, false, {
                                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                            lineNumber: 794,
                                                                                                            columnNumber: 53
                                                                                                        }, this)),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                                        className: "text-start px-4 py-2.5 font-medium hidden sm:table-cell",
                                                                                                        children: T.colMemo
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 796,
                                                                                                        columnNumber: 51
                                                                                                    }, this),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                                        className: "text-start px-4 py-2.5 font-medium hidden lg:table-cell",
                                                                                                        children: T.colComment
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 797,
                                                                                                        columnNumber: 51
                                                                                                    }, this)
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 792,
                                                                                                columnNumber: 49
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                            lineNumber: 791,
                                                                                            columnNumber: 47
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                                                            className: "divide-y divide-[#f5f0e8]",
                                                                                            children: sorted.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                                                    className: "hover:bg-[#faf8f4]",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                                            className: "px-4 py-3 text-[#555]",
                                                                                                            children: s.date
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                            lineNumber: 803,
                                                                                                            columnNumber: 53
                                                                                                        }, this),
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                                            className: "px-4 py-3",
                                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                                className: `px-2 py-0.5 rounded-full text-xs font-medium border ${s.present ? "text-emerald-700 bg-emerald-50 border-emerald-200" : "text-red-700 bg-red-50 border-red-200"}`,
                                                                                                                children: s.present ? T.present : T.absent
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                                lineNumber: 805,
                                                                                                                columnNumber: 55
                                                                                                            }, this)
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                            lineNumber: 804,
                                                                                                            columnNumber: 53
                                                                                                        }, this),
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                                            className: "px-4 py-3",
                                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                                className: `px-2 py-0.5 rounded-full text-xs font-medium border ${DISC_CLS[s.discipline]}`,
                                                                                                                children: T.disciplines[s.discipline]
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                                lineNumber: 809,
                                                                                                                columnNumber: 79
                                                                                                            }, this)
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                            lineNumber: 809,
                                                                                                            columnNumber: 53
                                                                                                        }, this),
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                                            className: "px-4 py-3 text-[#666] hidden sm:table-cell",
                                                                                                            children: s.memorization || "—"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                            lineNumber: 810,
                                                                                                            columnNumber: 53
                                                                                                        }, this),
                                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                                            className: "px-4 py-3 text-[#666] hidden lg:table-cell max-w-xs truncate",
                                                                                                            children: s.comment || "—"
                                                                                                        }, void 0, false, {
                                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                            lineNumber: 811,
                                                                                                            columnNumber: 53
                                                                                                        }, this)
                                                                                                    ]
                                                                                                }, s.id, true, {
                                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                    lineNumber: 802,
                                                                                                    columnNumber: 51
                                                                                                }, this))
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                            lineNumber: 800,
                                                                                            columnNumber: 47
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 790,
                                                                                    columnNumber: 45
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 789,
                                                                                columnNumber: 43
                                                                            }, this),
                                                                            showNewSession === student.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "bg-[#faf8f4] rounded-xl border border-[#e8dfc8] p-4",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                        className: "text-sm font-semibold text-[#1a1a1a] mb-4",
                                                                                        children: T.newSession
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 820,
                                                                                        columnNumber: 45
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "grid sm:grid-cols-2 gap-3",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                                        className: LABEL,
                                                                                                        children: T.fieldDate
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 822,
                                                                                                        columnNumber: 52
                                                                                                    }, this),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                                        type: "date",
                                                                                                        className: INPUT,
                                                                                                        value: sessionForm.date,
                                                                                                        onChange: (e)=>setSessionForm({
                                                                                                                ...sessionForm,
                                                                                                                date: e.target.value
                                                                                                            })
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 822,
                                                                                                        columnNumber: 98
                                                                                                    }, this)
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 822,
                                                                                                columnNumber: 47
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                                        className: LABEL,
                                                                                                        children: T.fieldPresence
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 824,
                                                                                                        columnNumber: 49
                                                                                                    }, this),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                        className: "flex gap-2 mt-1",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                                                type: "button",
                                                                                                                onClick: ()=>setSessionForm({
                                                                                                                        ...sessionForm,
                                                                                                                        present: true
                                                                                                                    }),
                                                                                                                className: `flex-1 py-2.5 rounded-lg text-xs font-semibold transition-colors border ${sessionForm.present ? "bg-emerald-600 text-white border-emerald-600" : "bg-white border-[#e8dfc8] text-[#666] hover:bg-[#f5f0e8]"}`,
                                                                                                                children: T.present
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                                lineNumber: 826,
                                                                                                                columnNumber: 51
                                                                                                            }, this),
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                                                type: "button",
                                                                                                                onClick: ()=>setSessionForm({
                                                                                                                        ...sessionForm,
                                                                                                                        present: false
                                                                                                                    }),
                                                                                                                className: `flex-1 py-2.5 rounded-lg text-xs font-semibold transition-colors border ${!sessionForm.present ? "bg-red-500 text-white border-red-500" : "bg-white border-[#e8dfc8] text-[#666] hover:bg-[#f5f0e8]"}`,
                                                                                                                children: T.absent
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                                lineNumber: 827,
                                                                                                                columnNumber: 51
                                                                                                            }, this)
                                                                                                        ]
                                                                                                    }, void 0, true, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 825,
                                                                                                        columnNumber: 49
                                                                                                    }, this)
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 823,
                                                                                                columnNumber: 47
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                                        className: LABEL,
                                                                                                        children: T.fieldDiscipline
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 831,
                                                                                                        columnNumber: 49
                                                                                                    }, this),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                                                                        className: INPUT,
                                                                                                        value: sessionForm.discipline,
                                                                                                        onChange: (e)=>setSessionForm({
                                                                                                                ...sessionForm,
                                                                                                                discipline: e.target.value
                                                                                                            }),
                                                                                                        children: [
                                                                                                            "excellent",
                                                                                                            "bon",
                                                                                                            "passable",
                                                                                                            "insuffisant"
                                                                                                        ].map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                                                                value: d,
                                                                                                                children: T.disciplines[d]
                                                                                                            }, d, false, {
                                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                                lineNumber: 833,
                                                                                                                columnNumber: 129
                                                                                                            }, this))
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 832,
                                                                                                        columnNumber: 49
                                                                                                    }, this)
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 830,
                                                                                                columnNumber: 47
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                                        className: LABEL,
                                                                                                        children: T.fieldMemo
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 836,
                                                                                                        columnNumber: 52
                                                                                                    }, this),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                                        className: INPUT,
                                                                                                        placeholder: T.memoPh,
                                                                                                        value: sessionForm.memorization,
                                                                                                        onChange: (e)=>setSessionForm({
                                                                                                                ...sessionForm,
                                                                                                                memorization: e.target.value
                                                                                                            })
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 836,
                                                                                                        columnNumber: 98
                                                                                                    }, this)
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 836,
                                                                                                columnNumber: 47
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                className: "sm:col-span-2",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                                        className: LABEL,
                                                                                                        children: T.fieldComment
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 837,
                                                                                                        columnNumber: 78
                                                                                                    }, this),
                                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                                                                        rows: 3,
                                                                                                        className: `${INPUT} resize-none`,
                                                                                                        placeholder: T.commentPh,
                                                                                                        value: sessionForm.comment,
                                                                                                        onChange: (e)=>setSessionForm({
                                                                                                                ...sessionForm,
                                                                                                                comment: e.target.value
                                                                                                            })
                                                                                                    }, void 0, false, {
                                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                        lineNumber: 837,
                                                                                                        columnNumber: 127
                                                                                                    }, this)
                                                                                                ]
                                                                                            }, void 0, true, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 837,
                                                                                                columnNumber: 47
                                                                                            }, this)
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 821,
                                                                                        columnNumber: 45
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "flex gap-2 mt-4",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                                onClick: ()=>handleAddSession(student.id),
                                                                                                className: "px-4 py-2 rounded-lg bg-[#2d6a4f] text-white text-xs font-semibold hover:bg-[#235a40] transition-colors",
                                                                                                children: T.saveSession
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 840,
                                                                                                columnNumber: 47
                                                                                            }, this),
                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                                onClick: ()=>setShowNewSession(null),
                                                                                                className: "px-4 py-2 rounded-lg border border-[#e8dfc8] text-[#666] text-xs hover:bg-white transition-colors",
                                                                                                children: T.cancel
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                                lineNumber: 841,
                                                                                                columnNumber: 47
                                                                                            }, this)
                                                                                        ]
                                                                                    }, void 0, true, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 839,
                                                                                        columnNumber: 45
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 819,
                                                                                columnNumber: 43
                                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: ()=>{
                                                                                    setShowNewSession(student.id);
                                                                                    setSessionForm(emptySession());
                                                                                },
                                                                                className: "flex items-center gap-1.5 text-sm font-semibold text-[#2d6a4f] hover:underline",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                                                        size: 14
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 846,
                                                                                        columnNumber: 45
                                                                                    }, this),
                                                                                    T.addSession
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 845,
                                                                                columnNumber: 43
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 784,
                                                                        columnNumber: 39
                                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "space-y-4",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MemoMap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                                value: memoEdit,
                                                                                editable: true,
                                                                                lang: lang,
                                                                                onChange: (updated)=>setMemoEdit(updated)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 852,
                                                                                columnNumber: 41
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                onClick: ()=>handleSaveMemo(student.id),
                                                                                className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                                                children: T.memoSave
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 853,
                                                                                columnNumber: 41
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 851,
                                                                        columnNumber: 39
                                                                    }, this)
                                                                ]
                                                            }, void 0, true)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 747,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true)
                                            }, student.id, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 703,
                                                columnNumber: 23
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 695,
                                        columnNumber: 17
                                    }, this),
                                    pageCount > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mt-2 px-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setPage((p)=>Math.max(0, p - 1)),
                                                disabled: page === 0,
                                                className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#e8dfc8] text-sm text-[#666] hover:bg-[#f5f0e8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                                        size: 14
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 871,
                                                        columnNumber: 23
                                                    }, this),
                                                    T.prevPage
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 870,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-sm text-[#888]",
                                                children: [
                                                    page + 1,
                                                    " / ",
                                                    pageCount
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 873,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setPage((p)=>Math.min(pageCount - 1, p + 1)),
                                                disabled: page === pageCount - 1,
                                                className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#e8dfc8] text-sm text-[#666] hover:bg-[#f5f0e8] disabled:opacity-40 disabled:cursor-not-allowed transition-colors",
                                                children: [
                                                    T.nextPage,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                                        size: 14
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 875,
                                                        columnNumber: 35
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 874,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 869,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 642,
                        columnNumber: 11
                    }, this),
                    tab === "professors" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-end",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        setShowAddProf(!showAddProf);
                                        setProfErr("");
                                    },
                                    className: "flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                            size: 15
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 889,
                                            columnNumber: 17
                                        }, this),
                                        T.addProf
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                    lineNumber: 888,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 887,
                                columnNumber: 13
                            }, this),
                            showAddProf && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-2xl border border-[#e8dfc8] p-6 shadow-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mb-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-bold text-[#1a1a1a]",
                                                children: T.newProf
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 895,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowAddProf(false),
                                                className: "text-[#bbb] hover:text-[#555]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 896,
                                                    columnNumber: 107
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 896,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 894,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid sm:grid-cols-2 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldName
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 899,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        className: INPUT,
                                                        placeholder: "Sheikh Omar",
                                                        value: profForm.name,
                                                        onChange: (e)=>setProfForm({
                                                                ...profForm,
                                                                name: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 899,
                                                        columnNumber: 70
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 899,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldEmail
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 900,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "email",
                                                        className: INPUT,
                                                        dir: "ltr",
                                                        placeholder: "omar@nur.com",
                                                        value: profForm.email,
                                                        onChange: (e)=>setProfForm({
                                                                ...profForm,
                                                                email: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 900,
                                                        columnNumber: 71
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 900,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldPassword
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 901,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "password",
                                                        className: INPUT,
                                                        placeholder: "••••••••",
                                                        value: profForm.password,
                                                        onChange: (e)=>setProfForm({
                                                                ...profForm,
                                                                password: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 901,
                                                        columnNumber: 74
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 901,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.fieldSpecialty
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 902,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        className: INPUT,
                                                        placeholder: T.specialtyPh,
                                                        value: profForm.specialty,
                                                        onChange: (e)=>setProfForm({
                                                                ...profForm,
                                                                specialty: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 902,
                                                        columnNumber: 75
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 902,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 898,
                                        columnNumber: 17
                                    }, this),
                                    profErr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-red-500 text-sm mt-3",
                                        children: profErr
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 904,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-3 mt-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleAddProf,
                                                className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                children: T.save
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 906,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowAddProf(false),
                                                className: "px-5 py-2.5 rounded-xl border border-[#e8dfc8] text-[#666] text-sm hover:bg-[#f5f0e8] transition-colors",
                                                children: T.cancel
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 907,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 905,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 893,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-4",
                                children: professors.map((prof)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-2xl border border-[#e8dfc8] p-5 shadow-sm",
                                        children: deletingProfId === prof.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-medium text-red-700 mb-3",
                                                    children: T.confirmDelete
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 916,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleDeleteProf(prof.id),
                                                            className: "px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors",
                                                            children: T.confirmYes
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 918,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setDeletingProfId(null),
                                                            className: "px-3 py-1.5 rounded-lg border border-[#e8dfc8] text-[#666] text-xs hover:bg-[#f5f0e8] transition-colors",
                                                            children: T.cancel
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 919,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 917,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 915,
                                            columnNumber: 21
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-start justify-between mb-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "w-11 h-11 rounded-full bg-[#2d6a4f]/10 flex items-center justify-center text-[#2d6a4f] font-bold text-sm shrink-0",
                                                                    children: initials(prof.name)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 926,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "font-semibold text-[#1a1a1a] text-sm",
                                                                            children: prof.name
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 928,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "text-xs text-[#c9a84c] font-medium",
                                                                            children: prof.specialty || T.professor
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 929,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 927,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 925,
                                                            columnNumber: 25
                                                        }, this),
                                                        prof.id !== user.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setDeletingProfId(prof.id),
                                                            className: "p-1.5 rounded-lg text-[#bbb] hover:text-red-500 hover:bg-red-50 transition-colors",
                                                            title: T.deleteLabel,
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                size: 14
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 933,
                                                                columnNumber: 194
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 933,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 924,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-xs text-[#aaa]",
                                                    children: prof.email
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 936,
                                                    columnNumber: 23
                                                }, this),
                                                prof.id === user.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "mt-3 inline-block text-xs bg-[#2d6a4f]/10 text-[#2d6a4f] px-2.5 py-0.5 rounded-full font-semibold",
                                                    children: T.yourAccount
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 937,
                                                    columnNumber: 47
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    }, prof.id, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 913,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 911,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 886,
                        columnNumber: 11
                    }, this),
                    tab === "top3" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-2xl border border-[#e8dfc8] p-6 shadow-sm max-w-lg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"], {
                                        size: 20,
                                        className: "text-[#c9a84c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 949,
                                        columnNumber: 59
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "font-bold text-[#1a1a1a]",
                                        children: T.top3Title
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 949,
                                        columnNumber: 106
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 949,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-4",
                                children: [
                                    "r1",
                                    "r2",
                                    "r3"
                                ].map((key, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: LABEL,
                                                children: [
                                                    T.rank1,
                                                    T.rank2,
                                                    T.rank3
                                                ][i]
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 953,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                className: INPUT,
                                                value: topForm[key],
                                                onChange: (e)=>setTopForm({
                                                        ...topForm,
                                                        [key]: e.target.value
                                                    }),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        children: T.top3None
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 955,
                                                        columnNumber: 21
                                                    }, this),
                                                    students.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            value: s.id,
                                                            children: s.name
                                                        }, s.id, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 956,
                                                            columnNumber: 42
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 954,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, key, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 952,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 950,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSaveTop3,
                                className: "mt-6 px-5 py-2.5 rounded-xl bg-[#c9a84c] text-white text-sm font-semibold hover:bg-[#b8943e] transition-colors",
                                children: T.top3Save
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 961,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 948,
                        columnNumber: 11
                    }, this),
                    tab === "announcements" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "font-bold text-[#1a1a1a]",
                                        children: T.annTitle
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 969,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setShowAddAnn(!showAddAnn);
                                            setAnnErr("");
                                        },
                                        className: "flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors shadow-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                size: 15
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 971,
                                                columnNumber: 17
                                            }, this),
                                            T.addAnnouncement
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 970,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 968,
                                columnNumber: 13
                            }, this),
                            showAddAnn && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-2xl border border-[#e8dfc8] p-6 shadow-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mb-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-bold text-[#1a1a1a]",
                                                children: T.newAnnouncement
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 978,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowAddAnn(false),
                                                className: "text-[#bbb] hover:text-[#555]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 979,
                                                    columnNumber: 106
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 979,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 977,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.annFieldTitle
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 982,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        className: INPUT,
                                                        value: annForm.title,
                                                        onChange: (e)=>setAnnForm({
                                                                ...annForm,
                                                                title: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 982,
                                                        columnNumber: 74
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 982,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.annFieldBody
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 983,
                                                        columnNumber: 24
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        rows: 4,
                                                        className: `${INPUT} resize-none`,
                                                        placeholder: T.annBodyPh,
                                                        value: annForm.body,
                                                        onChange: (e)=>setAnnForm({
                                                                ...annForm,
                                                                body: e.target.value
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 983,
                                                        columnNumber: 73
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 983,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: LABEL,
                                                        children: T.annFieldImage
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 985,
                                                        columnNumber: 21
                                                    }, this),
                                                    annForm.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: annForm.image,
                                                        className: "w-full max-h-48 object-cover rounded-xl mb-2",
                                                        alt: ""
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 986,
                                                        columnNumber: 39
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "file",
                                                        accept: "image/*",
                                                        className: "text-xs text-[#666] file:me-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-[#2d6a4f]/10 file:text-[#2d6a4f] file:font-semibold cursor-pointer",
                                                        onChange: async (e)=>{
                                                            const f = e.target.files?.[0];
                                                            if (f) setAnnForm({
                                                                ...annForm,
                                                                image: await resizeAnnImage(f)
                                                            });
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 987,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 984,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 981,
                                        columnNumber: 17
                                    }, this),
                                    annErr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-red-500 text-sm mt-3",
                                        children: annErr
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 991,
                                        columnNumber: 28
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-3 mt-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleAddAnnouncement,
                                                className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                children: T.save
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 993,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowAddAnn(false),
                                                className: "px-5 py-2.5 rounded-xl border border-[#e8dfc8] text-[#666] text-sm hover:bg-[#f5f0e8] transition-colors",
                                                children: T.cancel
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 994,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 992,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 976,
                                columnNumber: 15
                            }, this),
                            announcements.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center py-20 text-[#ccc]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                        size: 44,
                                        className: "mx-auto mb-3 opacity-40"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1000,
                                        columnNumber: 62
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm",
                                        children: T.noAnnouncements
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1000,
                                        columnNumber: 116
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 1000,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid sm:grid-cols-2 lg:grid-cols-3 gap-4",
                                children: announcements.map((ann)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-2xl border border-[#e8dfc8] overflow-hidden shadow-sm flex flex-col",
                                        children: deletingAnnId === ann.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-5 flex flex-col gap-3 bg-red-50 flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-medium text-red-700",
                                                    children: T.confirmDelete
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1007,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleDeleteAnnouncement(ann.id),
                                                            className: "px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors",
                                                            children: T.confirmYes
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1009,
                                                            columnNumber: 27
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setDeletingAnnId(null),
                                                            className: "px-3 py-1.5 rounded-lg border border-[#e8dfc8] text-[#666] text-xs hover:bg-white transition-colors",
                                                            children: T.cancel
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1010,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1008,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 1006,
                                            columnNumber: 23
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                ann.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: ann.image,
                                                    className: "w-full h-40 object-cover",
                                                    alt: ""
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1015,
                                                    columnNumber: 39
                                                }, this),
                                                !ann.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "w-full h-16 bg-[#2d6a4f]/5 flex items-center justify-center",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                                        size: 22,
                                                        className: "text-[#2d6a4f]/20"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 1016,
                                                        columnNumber: 117
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1016,
                                                    columnNumber: 40
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-4 flex flex-col flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-start justify-between gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "min-w-0",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "text-[10px] text-[#c9a84c] font-semibold",
                                                                            children: ann.date
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 1020,
                                                                            columnNumber: 31
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                            className: "font-bold text-[#1a1a1a] text-sm mt-0.5 leading-snug",
                                                                            children: ann.title
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 1021,
                                                                            columnNumber: 31
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1019,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>setDeletingAnnId(ann.id),
                                                                    className: "p-1.5 rounded-lg text-[#bbb] hover:text-red-500 hover:bg-red-50 transition-colors shrink-0",
                                                                    title: T.deleteLabel,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                        size: 13
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1023,
                                                                        columnNumber: 203
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1023,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1018,
                                                            columnNumber: 27
                                                        }, this),
                                                        ann.body && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-[#666] mt-2 leading-relaxed line-clamp-3",
                                                            children: ann.body
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1025,
                                                            columnNumber: 40
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1017,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    }, ann.id, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1004,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 1002,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 967,
                        columnNumber: 11
                    }, this),
                    tab === "exams" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "font-bold text-[#1a1a1a]",
                                        children: T.tabExams
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1039,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            setShowCreateExam(!showCreateExam);
                                            setExamErr("");
                                            setExamForm(emptyExamDraft());
                                        },
                                        className: "flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors shadow-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                size: 15
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1042,
                                                columnNumber: 17
                                            }, this),
                                            T.createExam
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1040,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 1038,
                                columnNumber: 13
                            }, this),
                            showCreateExam && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-2xl border border-[#e8dfc8] p-6 shadow-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between mb-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-bold text-[#1a1a1a]",
                                                children: T.newExam
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1049,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowCreateExam(false),
                                                className: "text-[#bbb] hover:text-[#555]",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    size: 18
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1050,
                                                    columnNumber: 110
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1050,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1048,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: LABEL,
                                                children: T.examFieldTitle
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1054,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                className: INPUT,
                                                value: examForm.title,
                                                onChange: (e)=>setExamForm({
                                                        ...examForm,
                                                        title: e.target.value
                                                    })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1055,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1053,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-5",
                                        children: examForm.questions.map((q, qi)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-[#faf8f4] rounded-xl border border-[#e8dfc8] p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between mb-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs font-bold text-[#2d6a4f] uppercase tracking-wider",
                                                                children: T.questionLabel(qi + 1)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 1062,
                                                                columnNumber: 25
                                                            }, this),
                                                            examForm.questions.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>setExamForm({
                                                                        ...examForm,
                                                                        questions: examForm.questions.filter((_, i)=>i !== qi)
                                                                    }),
                                                                className: "text-xs text-red-400 hover:text-red-600 font-medium",
                                                                children: T.removeQuestion
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 1064,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 1061,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mb-3",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                            rows: 2,
                                                            className: `${INPUT} resize-none`,
                                                            placeholder: T.questionPh,
                                                            value: q.text,
                                                            onChange: (e)=>{
                                                                const qs = examForm.questions.map((x, i)=>i === qi ? {
                                                                        ...x,
                                                                        text: e.target.value
                                                                    } : x);
                                                                setExamForm({
                                                                    ...examForm,
                                                                    questions: qs
                                                                });
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1069,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 1068,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "grid sm:grid-cols-2 gap-2 mb-3",
                                                        children: q.options.map((opt, oi)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "w-5 h-5 rounded-full bg-[#2d6a4f]/10 text-[#2d6a4f] text-[10px] font-bold flex items-center justify-center shrink-0",
                                                                        children: OPTION_LABELS[oi]
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1078,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        className: `${INPUT} text-xs`,
                                                                        placeholder: T.optionPh,
                                                                        value: opt.text,
                                                                        onChange: (e)=>{
                                                                            const qs = examForm.questions.map((x, i)=>i !== qi ? x : {
                                                                                    ...x,
                                                                                    options: x.options.map((o, j)=>j === oi ? {
                                                                                            ...o,
                                                                                            text: e.target.value
                                                                                        } : o)
                                                                                });
                                                                            setExamForm({
                                                                                ...examForm,
                                                                                questions: qs
                                                                            });
                                                                        }
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1079,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, opt.id, true, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 1077,
                                                                columnNumber: 27
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 1075,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                className: "text-[10px] font-semibold text-[#555] uppercase tracking-wider",
                                                                children: T.correctAnswer
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 1090,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex gap-2 mt-1.5 flex-wrap",
                                                                children: q.options.map((opt, oi)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        onClick: ()=>{
                                                                            const qs = examForm.questions.map((x, i)=>i === qi ? {
                                                                                    ...x,
                                                                                    correctOptionId: opt.id
                                                                                } : x);
                                                                            setExamForm({
                                                                                ...examForm,
                                                                                questions: qs
                                                                            });
                                                                        },
                                                                        className: `px-3 py-1 rounded-lg text-xs font-semibold transition-colors border ${q.correctOptionId === opt.id ? "bg-emerald-600 text-white border-emerald-600" : "bg-white border-[#e8dfc8] text-[#666] hover:bg-[#f5f0e8]"}`,
                                                                        children: OPTION_LABELS[oi]
                                                                    }, opt.id, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1093,
                                                                        columnNumber: 29
                                                                    }, this))
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 1091,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                        lineNumber: 1089,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, q.id, true, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1060,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1058,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setExamForm({
                                                ...examForm,
                                                questions: [
                                                    ...examForm.questions,
                                                    emptyQuestion()
                                                ]
                                            }),
                                        className: "mt-4 flex items-center gap-1.5 text-sm font-semibold text-[#2d6a4f] hover:underline",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1110,
                                                columnNumber: 19
                                            }, this),
                                            T.addQuestion
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1108,
                                        columnNumber: 17
                                    }, this),
                                    examErr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-red-500 text-sm mt-3",
                                        children: examErr
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1113,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-3 mt-5",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: handleSaveExam,
                                                className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                children: T.save
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1115,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setShowCreateExam(false),
                                                className: "px-5 py-2.5 rounded-xl border border-[#e8dfc8] text-[#666] text-sm hover:bg-[#f5f0e8] transition-colors",
                                                children: T.cancel
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                lineNumber: 1116,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1114,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 1047,
                                columnNumber: 15
                            }, this),
                            exams.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center py-20 text-[#ccc]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__["ClipboardList"], {
                                        size: 44,
                                        className: "mx-auto mb-3 opacity-40"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1122,
                                        columnNumber: 62
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm",
                                        children: T.noExams
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1122,
                                        columnNumber: 125
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 1122,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-3",
                                children: exams.map((exam)=>{
                                    const prof = profiles.find((u)=>u.id === exam.professorId);
                                    const results = examResults.filter((r)=>r.examId === exam.id);
                                    const isExpanded = expandedExamId === exam.id;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-2xl border border-[#e8dfc8] overflow-hidden shadow-sm",
                                        children: deletingExamId === exam.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-5 flex flex-wrap items-center justify-between gap-3 bg-red-50",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-medium text-red-700",
                                                    children: T.confirmDelete
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1133,
                                                    columnNumber: 27
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>handleDeleteExam(exam.id),
                                                            className: "px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs font-semibold hover:bg-red-600 transition-colors",
                                                            children: T.confirmYes
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1135,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setDeletingExamId(null),
                                                            className: "px-3 py-1.5 rounded-lg border border-[#e8dfc8] text-[#666] text-xs hover:bg-white transition-colors",
                                                            children: T.cancel
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1136,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1134,
                                                    columnNumber: 27
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                            lineNumber: 1132,
                                            columnNumber: 25
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    onClick: ()=>setExpandedExamId(isExpanded ? null : exam.id),
                                                    className: "flex items-center justify-between p-4 sm:p-5 hover:bg-[#faf8f4] transition-colors cursor-pointer",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "min-w-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "font-semibold text-[#1a1a1a] text-sm",
                                                                    children: exam.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1143,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "text-xs text-[#aaa] mt-0.5",
                                                                    children: [
                                                                        T.questionsCount(exam.questions.length),
                                                                        " · ",
                                                                        exam.date,
                                                                        prof && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            children: [
                                                                                " · ",
                                                                                T.createdBy,
                                                                                " ",
                                                                                prof.name
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 1146,
                                                                            columnNumber: 42
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1144,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1142,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2 shrink-0",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-xs bg-[#f0ead8] text-[#888] px-2 py-0.5 rounded-full",
                                                                    children: [
                                                                        results.length,
                                                                        " ",
                                                                        lang === "ar" ? "نتيجة" : "résultat" + (results.length !== 1 ? "s" : "")
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1150,
                                                                    columnNumber: 31
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: (e)=>{
                                                                        e.stopPropagation();
                                                                        setDeletingExamId(exam.id);
                                                                    },
                                                                    className: "p-1.5 rounded-lg text-[#bbb] hover:text-red-500 hover:bg-red-50 transition-colors",
                                                                    title: T.deleteLabel,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                        size: 13
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1151,
                                                                        columnNumber: 225
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1151,
                                                                    columnNumber: 31
                                                                }, this),
                                                                isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                                    size: 16,
                                                                    className: "text-[#bbb]"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1152,
                                                                    columnNumber: 45
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                                    size: 16,
                                                                    className: "text-[#bbb]"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                    lineNumber: 1152,
                                                                    columnNumber: 95
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1149,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1141,
                                                    columnNumber: 27
                                                }, this),
                                                isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "border-t border-[#f0ead8] p-4 sm:p-5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                            className: "text-sm font-semibold text-[#1a1a1a] mb-3",
                                                            children: T.examResults
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1158,
                                                            columnNumber: 31
                                                        }, this),
                                                        results.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "text-xs text-[#ccc]",
                                                            children: T.noResults
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1160,
                                                            columnNumber: 33
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "overflow-x-auto rounded-xl border border-[#f0ead8]",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                                                className: "w-full text-xs",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                                        className: "bg-[#faf8f4]",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                            className: "text-[#aaa] uppercase tracking-wider",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                    className: "text-start px-4 py-2.5 font-medium",
                                                                                    children: T.resultStudent
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 1166,
                                                                                    columnNumber: 41
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                    className: "text-start px-4 py-2.5 font-medium",
                                                                                    children: T.resultScore
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 1167,
                                                                                    columnNumber: 41
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                                    className: "text-start px-4 py-2.5 font-medium",
                                                                                    children: T.resultDate
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                    lineNumber: 1168,
                                                                                    columnNumber: 41
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                            lineNumber: 1165,
                                                                            columnNumber: 39
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1164,
                                                                        columnNumber: 37
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                                        className: "divide-y divide-[#f5f0e8]",
                                                                        children: results.map((r)=>{
                                                                            const stu = students.find((s)=>s.id === r.studentId);
                                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                                className: "hover:bg-[#faf8f4]",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                        className: "px-4 py-3 text-[#555] font-medium",
                                                                                        children: stu?.name ?? r.studentId
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 1176,
                                                                                        columnNumber: 45
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                        className: "px-4 py-3",
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: `px-2.5 py-0.5 rounded-full text-xs font-semibold border ${scoreColor(r.score)}`,
                                                                                            children: [
                                                                                                r.correctCount,
                                                                                                "/",
                                                                                                r.totalCount,
                                                                                                " — ",
                                                                                                r.score,
                                                                                                "%"
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                            lineNumber: 1178,
                                                                                            columnNumber: 47
                                                                                        }, this)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 1177,
                                                                                        columnNumber: 45
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                        className: "px-4 py-3 text-[#888]",
                                                                                        children: r.dateTaken
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                        lineNumber: 1182,
                                                                                        columnNumber: 45
                                                                                    }, this)
                                                                                ]
                                                                            }, r.id, true, {
                                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                                lineNumber: 1175,
                                                                                columnNumber: 43
                                                                            }, this);
                                                                        })
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                        lineNumber: 1171,
                                                                        columnNumber: 37
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                                lineNumber: 1163,
                                                                columnNumber: 35
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                            lineNumber: 1162,
                                                            columnNumber: 33
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                                    lineNumber: 1157,
                                                    columnNumber: 29
                                                }, this)
                                            ]
                                        }, void 0, true)
                                    }, exam.id, false, {
                                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                        lineNumber: 1130,
                                        columnNumber: 21
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                                lineNumber: 1124,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/professor/page.tsx",
                        lineNumber: 1037,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/professor/page.tsx",
                lineNumber: 623,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/professor/page.tsx",
        lineNumber: 598,
        columnNumber: 5
    }, this);
}
_s(ProfessorDashboard, "iPEVn7elb091tFPWNFG1Ga6fNhc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ProfessorDashboard;
var _c;
__turbopack_context__.k.register(_c, "ProfessorDashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0jdelrb._.js.map