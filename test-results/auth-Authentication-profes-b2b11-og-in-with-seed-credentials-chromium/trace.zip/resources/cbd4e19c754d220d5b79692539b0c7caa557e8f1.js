(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0vay560._.css","static/chunks/node_modules_next_dist_0l5.6e8._.js","static/chunks/node_modules_@supabase_postgrest-js_dist_index_mjs_0eu3ylr._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_0.pzobh._.js","static/chunks/node_modules_001metl._.js","static/chunks/src_0vf32uq._.js"],
    source: "dynamic"
});
