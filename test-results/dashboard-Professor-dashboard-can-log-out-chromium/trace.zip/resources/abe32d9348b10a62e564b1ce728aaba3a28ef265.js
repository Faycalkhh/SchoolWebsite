(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_components_0n8r-w7._.js","static/chunks/node_modules_0sxk2hp._.js"],
    source: "dynamic"
});
