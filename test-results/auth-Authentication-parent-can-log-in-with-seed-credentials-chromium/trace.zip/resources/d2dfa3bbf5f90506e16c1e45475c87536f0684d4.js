(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/quran.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "JUZ_SURAHS",
    ()=>JUZ_SURAHS,
    "SURAHS",
    ()=>SURAHS,
    "countMemorized",
    ()=>countMemorized
]);
const SURAHS = [
    {
        n: 1,
        ar: "الفاتحة",
        fr: "Al-Fatiha",
        juz: 1,
        ayahs: 7
    },
    {
        n: 2,
        ar: "البقرة",
        fr: "Al-Baqara",
        juz: 1,
        ayahs: 286
    },
    {
        n: 3,
        ar: "آل عمران",
        fr: "Ali Imran",
        juz: 3,
        ayahs: 200
    },
    {
        n: 4,
        ar: "النساء",
        fr: "An-Nisa",
        juz: 4,
        ayahs: 176
    },
    {
        n: 5,
        ar: "المائدة",
        fr: "Al-Ma'ida",
        juz: 6,
        ayahs: 120
    },
    {
        n: 6,
        ar: "الأنعام",
        fr: "Al-An'am",
        juz: 7,
        ayahs: 165
    },
    {
        n: 7,
        ar: "الأعراف",
        fr: "Al-A'raf",
        juz: 8,
        ayahs: 206
    },
    {
        n: 8,
        ar: "الأنفال",
        fr: "Al-Anfal",
        juz: 9,
        ayahs: 75
    },
    {
        n: 9,
        ar: "التوبة",
        fr: "At-Tawba",
        juz: 10,
        ayahs: 129
    },
    {
        n: 10,
        ar: "يونس",
        fr: "Yunus",
        juz: 11,
        ayahs: 109
    },
    {
        n: 11,
        ar: "هود",
        fr: "Hud",
        juz: 11,
        ayahs: 123
    },
    {
        n: 12,
        ar: "يوسف",
        fr: "Yusuf",
        juz: 12,
        ayahs: 111
    },
    {
        n: 13,
        ar: "الرعد",
        fr: "Ar-Ra'd",
        juz: 13,
        ayahs: 43
    },
    {
        n: 14,
        ar: "إبراهيم",
        fr: "Ibrahim",
        juz: 13,
        ayahs: 52
    },
    {
        n: 15,
        ar: "الحجر",
        fr: "Al-Hijr",
        juz: 13,
        ayahs: 99
    },
    {
        n: 16,
        ar: "النحل",
        fr: "An-Nahl",
        juz: 14,
        ayahs: 128
    },
    {
        n: 17,
        ar: "الإسراء",
        fr: "Al-Isra",
        juz: 15,
        ayahs: 111
    },
    {
        n: 18,
        ar: "الكهف",
        fr: "Al-Kahf",
        juz: 15,
        ayahs: 110
    },
    {
        n: 19,
        ar: "مريم",
        fr: "Maryam",
        juz: 16,
        ayahs: 98
    },
    {
        n: 20,
        ar: "طه",
        fr: "Ta-Ha",
        juz: 16,
        ayahs: 135
    },
    {
        n: 21,
        ar: "الأنبياء",
        fr: "Al-Anbiya",
        juz: 17,
        ayahs: 112
    },
    {
        n: 22,
        ar: "الحج",
        fr: "Al-Hajj",
        juz: 17,
        ayahs: 78
    },
    {
        n: 23,
        ar: "المؤمنون",
        fr: "Al-Mu'minun",
        juz: 18,
        ayahs: 118
    },
    {
        n: 24,
        ar: "النور",
        fr: "An-Nur",
        juz: 18,
        ayahs: 64
    },
    {
        n: 25,
        ar: "الفرقان",
        fr: "Al-Furqan",
        juz: 18,
        ayahs: 77
    },
    {
        n: 26,
        ar: "الشعراء",
        fr: "Ash-Shu'ara",
        juz: 19,
        ayahs: 227
    },
    {
        n: 27,
        ar: "النمل",
        fr: "An-Naml",
        juz: 19,
        ayahs: 93
    },
    {
        n: 28,
        ar: "القصص",
        fr: "Al-Qasas",
        juz: 20,
        ayahs: 88
    },
    {
        n: 29,
        ar: "العنكبوت",
        fr: "Al-Ankabut",
        juz: 20,
        ayahs: 69
    },
    {
        n: 30,
        ar: "الروم",
        fr: "Ar-Rum",
        juz: 21,
        ayahs: 60
    },
    {
        n: 31,
        ar: "لقمان",
        fr: "Luqman",
        juz: 21,
        ayahs: 34
    },
    {
        n: 32,
        ar: "السجدة",
        fr: "As-Sajda",
        juz: 21,
        ayahs: 30
    },
    {
        n: 33,
        ar: "الأحزاب",
        fr: "Al-Ahzab",
        juz: 21,
        ayahs: 73
    },
    {
        n: 34,
        ar: "سبأ",
        fr: "Saba",
        juz: 22,
        ayahs: 54
    },
    {
        n: 35,
        ar: "فاطر",
        fr: "Fatir",
        juz: 22,
        ayahs: 45
    },
    {
        n: 36,
        ar: "يس",
        fr: "Ya-Sin",
        juz: 22,
        ayahs: 83
    },
    {
        n: 37,
        ar: "الصافات",
        fr: "As-Saffat",
        juz: 23,
        ayahs: 182
    },
    {
        n: 38,
        ar: "ص",
        fr: "Sad",
        juz: 23,
        ayahs: 88
    },
    {
        n: 39,
        ar: "الزمر",
        fr: "Az-Zumar",
        juz: 23,
        ayahs: 75
    },
    {
        n: 40,
        ar: "غافر",
        fr: "Ghafir",
        juz: 24,
        ayahs: 85
    },
    {
        n: 41,
        ar: "فصلت",
        fr: "Fussilat",
        juz: 24,
        ayahs: 54
    },
    {
        n: 42,
        ar: "الشورى",
        fr: "Ash-Shura",
        juz: 25,
        ayahs: 53
    },
    {
        n: 43,
        ar: "الزخرف",
        fr: "Az-Zukhruf",
        juz: 25,
        ayahs: 89
    },
    {
        n: 44,
        ar: "الدخان",
        fr: "Ad-Dukhan",
        juz: 25,
        ayahs: 59
    },
    {
        n: 45,
        ar: "الجاثية",
        fr: "Al-Jathiya",
        juz: 25,
        ayahs: 37
    },
    {
        n: 46,
        ar: "الأحقاف",
        fr: "Al-Ahqaf",
        juz: 26,
        ayahs: 35
    },
    {
        n: 47,
        ar: "محمد",
        fr: "Muhammad",
        juz: 26,
        ayahs: 38
    },
    {
        n: 48,
        ar: "الفتح",
        fr: "Al-Fath",
        juz: 26,
        ayahs: 29
    },
    {
        n: 49,
        ar: "الحجرات",
        fr: "Al-Hujurat",
        juz: 26,
        ayahs: 18
    },
    {
        n: 50,
        ar: "ق",
        fr: "Qaf",
        juz: 26,
        ayahs: 45
    },
    {
        n: 51,
        ar: "الذاريات",
        fr: "Adh-Dhariyat",
        juz: 26,
        ayahs: 60
    },
    {
        n: 52,
        ar: "الطور",
        fr: "At-Tur",
        juz: 27,
        ayahs: 49
    },
    {
        n: 53,
        ar: "النجم",
        fr: "An-Najm",
        juz: 27,
        ayahs: 62
    },
    {
        n: 54,
        ar: "القمر",
        fr: "Al-Qamar",
        juz: 27,
        ayahs: 55
    },
    {
        n: 55,
        ar: "الرحمن",
        fr: "Ar-Rahman",
        juz: 27,
        ayahs: 78
    },
    {
        n: 56,
        ar: "الواقعة",
        fr: "Al-Waqi'a",
        juz: 27,
        ayahs: 96
    },
    {
        n: 57,
        ar: "الحديد",
        fr: "Al-Hadid",
        juz: 27,
        ayahs: 29
    },
    {
        n: 58,
        ar: "المجادلة",
        fr: "Al-Mujadila",
        juz: 28,
        ayahs: 22
    },
    {
        n: 59,
        ar: "الحشر",
        fr: "Al-Hashr",
        juz: 28,
        ayahs: 24
    },
    {
        n: 60,
        ar: "الممتحنة",
        fr: "Al-Mumtahina",
        juz: 28,
        ayahs: 13
    },
    {
        n: 61,
        ar: "الصف",
        fr: "As-Saf",
        juz: 28,
        ayahs: 14
    },
    {
        n: 62,
        ar: "الجمعة",
        fr: "Al-Jumu'a",
        juz: 28,
        ayahs: 11
    },
    {
        n: 63,
        ar: "المنافقون",
        fr: "Al-Munafiqun",
        juz: 28,
        ayahs: 11
    },
    {
        n: 64,
        ar: "التغابن",
        fr: "At-Taghabun",
        juz: 28,
        ayahs: 18
    },
    {
        n: 65,
        ar: "الطلاق",
        fr: "At-Talaq",
        juz: 28,
        ayahs: 12
    },
    {
        n: 66,
        ar: "التحريم",
        fr: "At-Tahrim",
        juz: 28,
        ayahs: 12
    },
    {
        n: 67,
        ar: "الملك",
        fr: "Al-Mulk",
        juz: 29,
        ayahs: 30
    },
    {
        n: 68,
        ar: "القلم",
        fr: "Al-Qalam",
        juz: 29,
        ayahs: 52
    },
    {
        n: 69,
        ar: "الحاقة",
        fr: "Al-Haqqah",
        juz: 29,
        ayahs: 52
    },
    {
        n: 70,
        ar: "المعارج",
        fr: "Al-Ma'arij",
        juz: 29,
        ayahs: 44
    },
    {
        n: 71,
        ar: "نوح",
        fr: "Nuh",
        juz: 29,
        ayahs: 28
    },
    {
        n: 72,
        ar: "الجن",
        fr: "Al-Jinn",
        juz: 29,
        ayahs: 28
    },
    {
        n: 73,
        ar: "المزمل",
        fr: "Al-Muzzammil",
        juz: 29,
        ayahs: 20
    },
    {
        n: 74,
        ar: "المدثر",
        fr: "Al-Muddathir",
        juz: 29,
        ayahs: 56
    },
    {
        n: 75,
        ar: "القيامة",
        fr: "Al-Qiyama",
        juz: 29,
        ayahs: 40
    },
    {
        n: 76,
        ar: "الإنسان",
        fr: "Al-Insan",
        juz: 29,
        ayahs: 31
    },
    {
        n: 77,
        ar: "المرسلات",
        fr: "Al-Mursalat",
        juz: 29,
        ayahs: 50
    },
    {
        n: 78,
        ar: "النبأ",
        fr: "An-Naba",
        juz: 30,
        ayahs: 40
    },
    {
        n: 79,
        ar: "النازعات",
        fr: "An-Nazi'at",
        juz: 30,
        ayahs: 46
    },
    {
        n: 80,
        ar: "عبس",
        fr: "Abasa",
        juz: 30,
        ayahs: 42
    },
    {
        n: 81,
        ar: "التكوير",
        fr: "At-Takwir",
        juz: 30,
        ayahs: 29
    },
    {
        n: 82,
        ar: "الانفطار",
        fr: "Al-Infitar",
        juz: 30,
        ayahs: 19
    },
    {
        n: 83,
        ar: "المطففين",
        fr: "Al-Mutaffifin",
        juz: 30,
        ayahs: 36
    },
    {
        n: 84,
        ar: "الانشقاق",
        fr: "Al-Inshiqaq",
        juz: 30,
        ayahs: 25
    },
    {
        n: 85,
        ar: "البروج",
        fr: "Al-Buruj",
        juz: 30,
        ayahs: 22
    },
    {
        n: 86,
        ar: "الطارق",
        fr: "At-Tariq",
        juz: 30,
        ayahs: 17
    },
    {
        n: 87,
        ar: "الأعلى",
        fr: "Al-Ala",
        juz: 30,
        ayahs: 19
    },
    {
        n: 88,
        ar: "الغاشية",
        fr: "Al-Ghashiya",
        juz: 30,
        ayahs: 26
    },
    {
        n: 89,
        ar: "الفجر",
        fr: "Al-Fajr",
        juz: 30,
        ayahs: 30
    },
    {
        n: 90,
        ar: "البلد",
        fr: "Al-Balad",
        juz: 30,
        ayahs: 20
    },
    {
        n: 91,
        ar: "الشمس",
        fr: "Ash-Shams",
        juz: 30,
        ayahs: 15
    },
    {
        n: 92,
        ar: "الليل",
        fr: "Al-Layl",
        juz: 30,
        ayahs: 21
    },
    {
        n: 93,
        ar: "الضحى",
        fr: "Ad-Duha",
        juz: 30,
        ayahs: 11
    },
    {
        n: 94,
        ar: "الشرح",
        fr: "Ash-Sharh",
        juz: 30,
        ayahs: 8
    },
    {
        n: 95,
        ar: "التين",
        fr: "At-Tin",
        juz: 30,
        ayahs: 8
    },
    {
        n: 96,
        ar: "العلق",
        fr: "Al-Alaq",
        juz: 30,
        ayahs: 19
    },
    {
        n: 97,
        ar: "القدر",
        fr: "Al-Qadr",
        juz: 30,
        ayahs: 5
    },
    {
        n: 98,
        ar: "البينة",
        fr: "Al-Bayyina",
        juz: 30,
        ayahs: 8
    },
    {
        n: 99,
        ar: "الزلزلة",
        fr: "Az-Zalzala",
        juz: 30,
        ayahs: 8
    },
    {
        n: 100,
        ar: "العاديات",
        fr: "Al-Adiyat",
        juz: 30,
        ayahs: 11
    },
    {
        n: 101,
        ar: "القارعة",
        fr: "Al-Qari'a",
        juz: 30,
        ayahs: 11
    },
    {
        n: 102,
        ar: "التكاثر",
        fr: "At-Takathur",
        juz: 30,
        ayahs: 8
    },
    {
        n: 103,
        ar: "العصر",
        fr: "Al-Asr",
        juz: 30,
        ayahs: 3
    },
    {
        n: 104,
        ar: "الهمزة",
        fr: "Al-Humaza",
        juz: 30,
        ayahs: 9
    },
    {
        n: 105,
        ar: "الفيل",
        fr: "Al-Fil",
        juz: 30,
        ayahs: 5
    },
    {
        n: 106,
        ar: "قريش",
        fr: "Quraysh",
        juz: 30,
        ayahs: 4
    },
    {
        n: 107,
        ar: "الماعون",
        fr: "Al-Ma'un",
        juz: 30,
        ayahs: 7
    },
    {
        n: 108,
        ar: "الكوثر",
        fr: "Al-Kawthar",
        juz: 30,
        ayahs: 3
    },
    {
        n: 109,
        ar: "الكافرون",
        fr: "Al-Kafirun",
        juz: 30,
        ayahs: 6
    },
    {
        n: 110,
        ar: "النصر",
        fr: "An-Nasr",
        juz: 30,
        ayahs: 3
    },
    {
        n: 111,
        ar: "المسد",
        fr: "Al-Masad",
        juz: 30,
        ayahs: 5
    },
    {
        n: 112,
        ar: "الإخلاص",
        fr: "Al-Ikhlas",
        juz: 30,
        ayahs: 4
    },
    {
        n: 113,
        ar: "الفلق",
        fr: "Al-Falaq",
        juz: 30,
        ayahs: 5
    },
    {
        n: 114,
        ar: "الناس",
        fr: "An-Nas",
        juz: 30,
        ayahs: 6
    }
];
const JUZ_SURAHS = Array.from({
    length: 30
}, (_, i)=>SURAHS.filter((s)=>s.juz === i + 1));
function countMemorized(memo) {
    return Object.values(memo).filter((s)=>s === "memorized").length;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/MemoMap.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MemoMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.mjs [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$quran$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/quran.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const STATUS_CYCLE = [
    "not_started",
    "in_progress",
    "memorized",
    "needs_revision"
];
const STATUS_CLS = {
    not_started: "bg-gray-100 text-gray-400 border-gray-200",
    in_progress: "bg-amber-50 text-amber-700 border-amber-300",
    memorized: "bg-emerald-50 text-emerald-700 border-emerald-300",
    needs_revision: "bg-red-50 text-red-600 border-red-300"
};
const JUZ_BAR_CLS = {
    not_started: "bg-gray-200",
    in_progress: "bg-amber-400",
    memorized: "bg-emerald-500",
    needs_revision: "bg-red-400"
};
const tMap = {
    ar: {
        juz: (n)=>`الجزء ${n}`,
        total: (n)=>`${n} / 114 سورة محفوظة`,
        legend: "المفتاح",
        statuses: {
            not_started: "لم يبدأ",
            in_progress: "جارٍ الحفظ",
            memorized: "محفوظ",
            needs_revision: "يحتاج مراجعة"
        },
        clickHint: "انقر على السورة لتغيير حالتها"
    },
    fr: {
        juz: (n)=>`Juz ${n}`,
        total: (n)=>`${n} / 114 sourates mémorisées`,
        legend: "Légende",
        statuses: {
            not_started: "Non commencé",
            in_progress: "En cours",
            memorized: "Mémorisé",
            needs_revision: "À réviser"
        },
        clickHint: "Cliquez sur une sourate pour changer son état"
    }
};
function getStatus(memo, n) {
    return memo[n] ?? "not_started";
}
function MemoMap({ value, editable = false, onChange, lang }) {
    _s();
    const T = tMap[lang];
    const [openJuz, setOpenJuz] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        30
    ]);
    const memorizedCount = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$quran$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["countMemorized"])(value);
    const totalPct = Math.round(memorizedCount / 114 * 100);
    function cycleStatus(n) {
        if (!editable || !onChange) return;
        const cur = getStatus(value, n);
        const next = STATUS_CYCLE[(STATUS_CYCLE.indexOf(cur) + 1) % STATUS_CYCLE.length];
        onChange({
            ...value,
            [n]: next
        });
    }
    function toggleJuz(juzNum) {
        setOpenJuz((prev)=>prev.includes(juzNum) ? prev.filter((j)=>j !== juzNum) : [
                ...prev,
                juzNum
            ]);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        dir: lang === "ar" ? "rtl" : "ltr",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row sm:items-center gap-3",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between mb-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs font-semibold text-[#2d6a4f]",
                                    children: T.total(memorizedCount)
                                }, void 0, false, {
                                    fileName: "[project]/src/components/MemoMap.tsx",
                                    lineNumber: 86,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-[#aaa]",
                                    children: [
                                        totalPct,
                                        "%"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/MemoMap.tsx",
                                    lineNumber: 87,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/MemoMap.tsx",
                            lineNumber: 85,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full h-2.5 bg-gray-100 rounded-full overflow-hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-full bg-emerald-500 rounded-full transition-all duration-500",
                                style: {
                                    width: `${totalPct}%`
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/components/MemoMap.tsx",
                                lineNumber: 90,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/MemoMap.tsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/MemoMap.tsx",
                    lineNumber: 84,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 items-center text-xs",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#aaa] font-semibold",
                        children: [
                            T.legend,
                            " :"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/MemoMap.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this),
                    [
                        "not_started",
                        "in_progress",
                        "memorized",
                        "needs_revision"
                    ].map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: `px-2 py-0.5 rounded-full border font-medium ${STATUS_CLS[s]}`,
                            children: T.statuses[s]
                        }, s, false, {
                            fileName: "[project]/src/components/MemoMap.tsx",
                            lineNumber: 101,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this),
            editable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[10px] text-[#bbb] italic",
                children: T.clickHint
            }, void 0, false, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 108,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-2",
                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$quran$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["JUZ_SURAHS"].map((surahs, idx)=>{
                    const juzNum = idx + 1;
                    const isOpen = openJuz.includes(juzNum);
                    const juzMemo = surahs.filter((s)=>getStatus(value, s.n) === "memorized").length;
                    const juzPct = Math.round(juzMemo / surahs.length * 100);
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border border-[#e8dfc8] rounded-xl overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>toggleJuz(juzNum),
                                className: "w-full flex items-center justify-between px-4 py-2.5 bg-[#faf8f4] hover:bg-[#f5f0e8] transition-colors text-start",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3 min-w-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-bold text-[#2d6a4f] shrink-0",
                                                children: T.juz(juzNum)
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 125,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-24 h-1.5 bg-gray-100 rounded-full overflow-hidden shrink-0",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "h-full bg-emerald-400 rounded-full transition-all",
                                                            style: {
                                                                width: `${juzPct}%`
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/MemoMap.tsx",
                                                            lineNumber: 128,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/MemoMap.tsx",
                                                        lineNumber: 127,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[10px] text-[#aaa] shrink-0",
                                                        children: [
                                                            juzMemo,
                                                            "/",
                                                            surahs.length
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/MemoMap.tsx",
                                                        lineNumber: 133,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 126,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/MemoMap.tsx",
                                        lineNumber: 124,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2 shrink-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden sm:flex gap-0.5",
                                                children: surahs.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `w-2 h-2 rounded-sm ${JUZ_BAR_CLS[getStatus(value, s.n)]}`
                                                    }, s.n, false, {
                                                        fileName: "[project]/src/components/MemoMap.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 23
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 137,
                                                columnNumber: 19
                                            }, this),
                                            isOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                size: 14,
                                                className: "text-[#bbb]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 145,
                                                columnNumber: 29
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                size: 14,
                                                className: "text-[#bbb]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 145,
                                                columnNumber: 79
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/MemoMap.tsx",
                                        lineNumber: 136,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/MemoMap.tsx",
                                lineNumber: 120,
                                columnNumber: 15
                            }, this),
                            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-3 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-1.5",
                                children: surahs.map((s)=>{
                                    const status = getStatus(value, s.n);
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>cycleStatus(s.n),
                                        disabled: !editable,
                                        className: `rounded-lg border px-2 py-1.5 text-center transition-colors ${STATUS_CLS[status]} ${editable ? "hover:opacity-75 cursor-pointer" : "cursor-default"}`,
                                        title: `${lang === "ar" ? s.ar : s.fr} — ${T.statuses[status]}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[10px] font-bold",
                                                children: s.n
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 161,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[10px] leading-tight mt-0.5 truncate",
                                                children: lang === "ar" ? s.ar : s.fr
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 162,
                                                columnNumber: 25
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-[9px] opacity-60 mt-0.5",
                                                children: [
                                                    s.ayahs,
                                                    "v"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/MemoMap.tsx",
                                                lineNumber: 165,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, s.n, true, {
                                        fileName: "[project]/src/components/MemoMap.tsx",
                                        lineNumber: 154,
                                        columnNumber: 23
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/src/components/MemoMap.tsx",
                                lineNumber: 150,
                                columnNumber: 17
                            }, this)
                        ]
                    }, juzNum, true, {
                        fileName: "[project]/src/components/MemoMap.tsx",
                        lineNumber: 119,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/src/components/MemoMap.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/MemoMap.tsx",
        lineNumber: 82,
        columnNumber: 5
    }, this);
}
_s(MemoMap, "YKqDgzfwvb48xy1AzEqsH+abTq0=");
_c = MemoMap;
var _c;
__turbopack_context__.k.register(_c, "MemoMap");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/dashboard/parent/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ParentDashboard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/book-open.mjs [app-client] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.mjs [app-client] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.mjs [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-up.mjs [app-client] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-check.mjs [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-x.mjs [app-client] (ecmascript) <export default as XCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.mjs [app-client] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clipboard-list.mjs [app-client] (ecmascript) <export default as ClipboardList>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/LanguageContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MemoMap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/MemoMap.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
const t = {
    ar: {
        schoolName: "نور القرآن",
        role: "فضاء ولي الأمر",
        logout: "تسجيل الخروج",
        greeting: (name)=>`مرحباً، ${name} 👋`,
        subtitle: (n)=>n > 1 ? "هذا متابعة أطفالك." : "هذا متابعة طفلك.",
        noChildren: "لا يوجد طالب مرتبط بحسابك حالياً.",
        noChildrenHint: "تواصل مع المدرسة للمزيد من المعلومات.",
        ageSuffix: "سنة",
        presentLabel: "الحضور",
        sessions: (n)=>`${n} حصة`,
        noSessions: "لم يتم تسجيل أي حصة بعد.",
        statSessions: "الحصص",
        statAttendance: "الحضور",
        statLastDisc: "آخر انضباط",
        sessionDetail: "تفاصيل الحصص",
        present: "حاضر",
        absent: "غائب",
        memo: "الحفظ:",
        topBadge: "من أفضل 3 طلاب الأسبوع",
        announcementsTitle: "إعلانات المدرسة",
        memoMapTitle: "خريطة الحفظ",
        examsTitle: "الاختبارات المتاحة",
        examsTakenTitle: "الاختبارات المنجزة",
        startExam: "ابدأ الاختبار",
        submitExam: "إرسال الإجابات",
        cancelExam: "إلغاء",
        errAllAnswers: "يرجى الإجابة على جميع الأسئلة.",
        questions: (n)=>`${n} سؤال`,
        scoreLabel: "النتيجة:",
        noExams: "لا توجد اختبارات متاحة حالياً.",
        disciplines: {
            excellent: "ممتاز",
            bon: "جيد",
            passable: "مقبول",
            insuffisant: "ضعيف"
        },
        levels: {
            "Débutant": "مبتدئ",
            "Intermédiaire": "متوسط",
            "Avancé": "متقدم",
            "Hifz": "حفظ"
        }
    },
    fr: {
        schoolName: "Nur Al-Quran",
        role: "Espace Parent",
        logout: "Déconnexion",
        greeting: (name)=>`Bonjour, ${name} 👋`,
        subtitle: (n)=>`Voici le suivi de ${n > 1 ? "vos enfants" : "votre enfant"}.`,
        noChildren: "Aucun élève associé à votre compte pour le moment.",
        noChildrenHint: "Contactez l'école pour plus d'informations.",
        ageSuffix: "ans",
        presentLabel: "présence",
        sessions: (n)=>`${n} séance${n !== 1 ? "s" : ""}`,
        noSessions: "Aucune séance enregistrée pour le moment.",
        statSessions: "Séances",
        statAttendance: "Présence",
        statLastDisc: "Dernière discipline",
        sessionDetail: "Détail des séances",
        present: "Présent",
        absent: "Absent",
        memo: "Mémorisation :",
        topBadge: "Top 3 de la semaine",
        announcementsTitle: "Annonces de l'école",
        memoMapTitle: "Carte de mémorisation",
        examsTitle: "Examens disponibles",
        examsTakenTitle: "Examens passés",
        startExam: "Commencer l'examen",
        submitExam: "Envoyer les réponses",
        cancelExam: "Annuler",
        errAllAnswers: "Veuillez répondre à toutes les questions.",
        questions: (n)=>`${n} question${n !== 1 ? "s" : ""}`,
        scoreLabel: "Score :",
        noExams: "Aucun examen disponible pour le moment.",
        disciplines: {
            excellent: "Excellent",
            bon: "Bon",
            passable: "Passable",
            insuffisant: "Insuffisant"
        },
        levels: {
            "Débutant": "Débutant",
            "Intermédiaire": "Intermédiaire",
            "Avancé": "Avancé",
            "Hifz": "Hifz"
        }
    }
};
const DISC_CLS = {
    excellent: "text-emerald-700 bg-emerald-50 border-emerald-200",
    bon: "text-blue-700 bg-blue-50 border-blue-200",
    passable: "text-amber-700 bg-amber-50 border-amber-200",
    insuffisant: "text-red-700 bg-red-50 border-red-200"
};
function attendanceRate(sessions) {
    if (!sessions.length) return null;
    return Math.round(sessions.filter((s)=>s.present).length / sessions.length * 100);
}
function initials(name) {
    return name.split(" ").map((w)=>w[0]).join("").slice(0, 2).toUpperCase();
}
function lastDiscipline(sessions) {
    if (!sessions.length) return null;
    return [
        ...sessions
    ].sort((a, b)=>b.date.localeCompare(a.date))[0].discipline;
}
const RANK_MEDALS = {
    1: "🥇",
    2: "🥈",
    3: "🥉"
};
function ParentDashboard() {
    _s();
    const { user, logout } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { lang, dir, setLang } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"])();
    const T = t[lang];
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [children, setChildren] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [professorNames, setProfessorNames] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [expandedId, setExpandedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [topStudents, setTopStudents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [announcements, setAnnouncements] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [exams, setExams] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [examResults, setExamResults] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [takingExam, setTakingExam] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [examAnswers, setExamAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [examSubmitErr, setExamSubmitErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ParentDashboard.useEffect": ()=>{
            if (!user) {
                router.push("/login");
                return;
            }
            if (user.role !== "parent") {
                router.push("/login");
                return;
            }
            ({
                "ParentDashboard.useEffect": async ()=>{
                    const [mine, profs, tops, anns, exs, results] = await Promise.all([
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStudentsByParent"])(user.id),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProfiles"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTopStudents"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAnnouncements"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExams"])(),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getExamResults"])()
                    ]);
                    setChildren(mine);
                    if (mine.length > 0) setExpandedId(mine[0].id);
                    const map = {};
                    profs.forEach({
                        "ParentDashboard.useEffect": (p)=>{
                            map[p.id] = p.name;
                        }
                    }["ParentDashboard.useEffect"]);
                    setProfessorNames(map);
                    setTopStudents(tops);
                    setAnnouncements(anns);
                    setExams(exs);
                    setExamResults(results);
                }
            })["ParentDashboard.useEffect"]();
        }
    }["ParentDashboard.useEffect"], [
        user,
        router
    ]);
    async function handleSubmitExam() {
        if (!takingExam) return;
        const exam = exams.find((e)=>e.id === takingExam.examId);
        if (!exam) return;
        if (exam.questions.some((q)=>!examAnswers[q.id])) {
            setExamSubmitErr(T.errAllAnswers);
            return;
        }
        const correct = exam.questions.filter((q)=>examAnswers[q.id] === q.correctOptionId).length;
        const score = Math.round(correct / exam.questions.length * 100);
        const result = {
            examId: exam.id,
            studentId: takingExam.studentId,
            answers: {
                ...examAnswers
            },
            score,
            correctCount: correct,
            totalCount: exam.questions.length,
            dateTaken: new Date().toISOString().split("T")[0]
        };
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addExamResult"])(result);
        setExamResults((prev)=>[
                ...prev,
                {
                    ...result,
                    id: `res_${Date.now()}`
                }
            ]);
        setTakingExam(null);
        setExamAnswers({});
        setExamSubmitErr("");
    }
    function scoreColor(score) {
        if (score >= 70) return "text-emerald-700 bg-emerald-50 border-emerald-200";
        if (score >= 50) return "text-amber-700 bg-amber-50 border-amber-200";
        return "text-red-700 bg-red-50 border-red-200";
    }
    if (!user) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-[#f5f0e8]",
        dir: dir,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "bg-white border-b border-[#e8dfc8] sticky top-0 z-30 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-5xl mx-auto px-4 lg:px-8 py-3.5 flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            className: "flex items-center gap-2.5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 rounded-full bg-[#2d6a4f] flex items-center justify-center shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                                        size: 15,
                                        className: "text-[#c9a84c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                        lineNumber: 192,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                    lineNumber: 191,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-bold text-[#2d6a4f] text-base hidden sm:block",
                                    children: T.schoolName
                                }, void 0, false, {
                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                    lineNumber: 194,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                            lineNumber: 190,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setLang(lang === "ar" ? "fr" : "ar"),
                                    className: "px-2.5 py-1.5 rounded-lg border border-[#e8dfc8] text-xs font-semibold text-[#555] hover:bg-[#f5f0e8] transition-colors",
                                    children: lang === "ar" ? "FR" : "عر"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                    lineNumber: 197,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden sm:block text-end",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-semibold text-[#1a1a1a]",
                                            children: user.name
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                            lineNumber: 204,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-xs text-[#c9a84c]",
                                            children: T.role
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                            lineNumber: 205,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                    lineNumber: 203,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        logout();
                                        router.push("/");
                                    },
                                    className: "flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm text-[#888] hover:text-red-600 hover:bg-red-50 transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                                            size: 15
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                            lineNumber: 211,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "hidden sm:inline",
                                            children: T.logout
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                            lineNumber: 212,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                    lineNumber: 207,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                            lineNumber: 196,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                    lineNumber: 189,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                lineNumber: 188,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "max-w-5xl mx-auto px-4 lg:px-8 py-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-xl font-bold text-[#1a1a1a]",
                                children: T.greeting(user.name.split(" ")[0])
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-[#888] mt-1",
                                children: T.subtitle(children.length)
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 221,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                        lineNumber: 219,
                        columnNumber: 9
                    }, this),
                    announcements.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                        size: 15,
                                        className: "text-[#c9a84c]"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                        lineNumber: 228,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-sm font-bold text-[#1a1a1a]",
                                        children: T.announcementsTitle
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                        lineNumber: 229,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 227,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid sm:grid-cols-2 gap-3",
                                children: announcements.map((ann)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-2xl border border-[#e8dfc8] overflow-hidden flex shadow-sm",
                                        children: [
                                            ann.image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: ann.image,
                                                className: "w-20 h-20 object-cover shrink-0",
                                                alt: ""
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 235,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-4 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-[10px] text-[#c9a84c] font-semibold mb-1",
                                                        children: ann.date
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 238,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-semibold text-[#1a1a1a] text-sm truncate",
                                                        children: ann.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 239,
                                                        columnNumber: 21
                                                    }, this),
                                                    ann.body && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs text-[#666] mt-1 line-clamp-2 leading-relaxed",
                                                        children: ann.body
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 240,
                                                        columnNumber: 34
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 237,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, ann.id, true, {
                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                        lineNumber: 233,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 231,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                        lineNumber: 226,
                        columnNumber: 11
                    }, this),
                    children.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center py-20 bg-white rounded-2xl border border-[#e8dfc8] shadow-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                                size: 44,
                                className: "mx-auto mb-3 text-[#e8dfc8]"
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 251,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-[#aaa]",
                                children: T.noChildren
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 252,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-[#ccc] mt-1",
                                children: T.noChildrenHint
                            }, void 0, false, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 253,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                        lineNumber: 250,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-5",
                        children: children.map((child)=>{
                            const sorted = [
                                ...child.sessions
                            ].sort((a, b)=>b.date.localeCompare(a.date));
                            const rate = attendanceRate(child.sessions);
                            const lastDisc = lastDiscipline(child.sessions);
                            const isExpanded = expandedId === child.id;
                            const levelLabel = T.levels[child.level] ?? child.level;
                            const topEntry = topStudents.find((e)=>e.studentId === child.id);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-white rounded-2xl border border-[#e8dfc8] overflow-hidden shadow-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setExpandedId(isExpanded ? null : child.id),
                                        className: "w-full flex items-center justify-between p-5 text-start hover:bg-[#faf8f4] transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-4",
                                                children: [
                                                    child.photo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                        src: child.photo,
                                                        className: "w-12 h-12 rounded-full object-cover shrink-0",
                                                        alt: ""
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 273,
                                                        columnNumber: 25
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-12 h-12 rounded-full bg-[#c9a84c]/15 flex items-center justify-center text-[#c9a84c] font-bold text-sm shrink-0",
                                                        children: initials(child.name)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 275,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2 flex-wrap",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "font-bold text-[#1a1a1a]",
                                                                        children: child.name
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 281,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    topEntry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-700",
                                                                        children: [
                                                                            RANK_MEDALS[topEntry.rank],
                                                                            " ",
                                                                            T.topBadge
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 283,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 280,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs text-[#aaa] mt-0.5",
                                                                children: [
                                                                    levelLabel,
                                                                    child.age > 0 ? ` · ${child.age} ${T.ageSuffix}` : ""
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 288,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 279,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 271,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "hidden sm:flex items-center gap-3 text-xs",
                                                        children: [
                                                            rate !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-end",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "font-bold text-[#1a1a1a] text-base",
                                                                        children: [
                                                                            rate,
                                                                            "%"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 297,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "text-[#aaa]",
                                                                        children: T.presentLabel
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 298,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 296,
                                                                columnNumber: 27
                                                            }, this),
                                                            lastDisc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `px-2.5 py-1 rounded-full font-medium border text-xs ${DISC_CLS[lastDisc]}`,
                                                                children: T.disciplines[lastDisc]
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 302,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[#ccc]",
                                                                children: T.sessions(child.sessions.length)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 306,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 294,
                                                        columnNumber: 23
                                                    }, this),
                                                    isExpanded ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                        size: 16,
                                                        className: "text-[#bbb] shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 308,
                                                        columnNumber: 37
                                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                        size: 16,
                                                        className: "text-[#bbb] shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 308,
                                                        columnNumber: 96
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 293,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                        lineNumber: 267,
                                        columnNumber: 19
                                    }, this),
                                    isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "border-t border-[#f0ead8] p-5 space-y-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-2 sm:grid-cols-3 gap-3",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-[#f5f0e8] rounded-xl p-4 text-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-2xl font-bold text-[#2d6a4f]",
                                                                children: child.sessions.length
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 316,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs text-[#888] mt-0.5",
                                                                children: T.statSessions
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 317,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 315,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-[#f5f0e8] rounded-xl p-4 text-center",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-2xl font-bold text-[#2d6a4f]",
                                                                children: [
                                                                    rate ?? "—",
                                                                    "%"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 320,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs text-[#888] mt-0.5",
                                                                children: T.statAttendance
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 321,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 319,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "bg-[#f5f0e8] rounded-xl p-4 text-center col-span-2 sm:col-span-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `text-sm font-bold mt-1 ${lastDisc ? DISC_CLS[lastDisc].split(" ")[0] : "text-[#aaa]"}`,
                                                                children: lastDisc ? T.disciplines[lastDisc] : "—"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 324,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-xs text-[#888] mt-0.5",
                                                                children: T.statLastDisc
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 327,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 323,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 314,
                                                columnNumber: 23
                                            }, this),
                                            child.memorization && Object.keys(child.memorization).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "text-sm font-semibold text-[#1a1a1a] mb-3",
                                                        children: T.memoMapTitle
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 334,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$MemoMap$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        value: child.memorization,
                                                        editable: false,
                                                        lang: lang
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 335,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 333,
                                                columnNumber: 25
                                            }, this),
                                            (()=>{
                                                const available = exams.filter((ex)=>!examResults.some((r)=>r.examId === ex.id && r.studentId === child.id));
                                                const taken = examResults.filter((r)=>r.studentId === child.id);
                                                const isThisExamActive = takingExam?.studentId === child.id;
                                                const activeExam = isThisExamActive ? exams.find((e)=>e.id === takingExam?.examId) : null;
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        activeExam && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "bg-white rounded-2xl border border-[#e8dfc8] p-5 mb-4 shadow-sm",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                    className: "text-sm font-bold text-[#1a1a1a] mb-4",
                                                                    children: activeExam.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 350,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "space-y-5",
                                                                    children: activeExam.questions.map((q, qi)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                    className: "text-sm font-semibold text-[#333] mb-2",
                                                                                    children: [
                                                                                        qi + 1,
                                                                                        ". ",
                                                                                        q.text
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                    lineNumber: 354,
                                                                                    columnNumber: 39
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "space-y-2",
                                                                                    children: q.options.map((opt, oi)=>{
                                                                                        const labels = [
                                                                                            "A",
                                                                                            "B",
                                                                                            "C",
                                                                                            "D"
                                                                                        ];
                                                                                        const selected = examAnswers[q.id] === opt.id;
                                                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                            type: "button",
                                                                                            onClick: ()=>{
                                                                                                setExamAnswers({
                                                                                                    ...examAnswers,
                                                                                                    [q.id]: opt.id
                                                                                                });
                                                                                                setExamSubmitErr("");
                                                                                            },
                                                                                            className: `w-full flex items-center gap-3 px-4 py-2.5 rounded-xl border text-sm text-start transition-colors ${selected ? "bg-[#2d6a4f] text-white border-[#2d6a4f]" : "bg-[#faf8f4] border-[#e8dfc8] text-[#444] hover:border-[#2d6a4f]/40"}`,
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: `w-6 h-6 rounded-full shrink-0 text-xs font-bold flex items-center justify-center ${selected ? "bg-white/20 text-white" : "bg-[#2d6a4f]/10 text-[#2d6a4f]"}`,
                                                                                                    children: labels[oi]
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                                    lineNumber: 363,
                                                                                                    columnNumber: 47
                                                                                                }, this),
                                                                                                opt.text
                                                                                            ]
                                                                                        }, opt.id, true, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 360,
                                                                                            columnNumber: 45
                                                                                        }, this);
                                                                                    })
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                    lineNumber: 355,
                                                                                    columnNumber: 39
                                                                                }, this)
                                                                            ]
                                                                        }, q.id, true, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 353,
                                                                            columnNumber: 37
                                                                        }, this))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 351,
                                                                    columnNumber: 33
                                                                }, this),
                                                                examSubmitErr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-red-500 text-xs mt-3",
                                                                    children: examSubmitErr
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 372,
                                                                    columnNumber: 51
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex gap-3 mt-5",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: handleSubmitExam,
                                                                            className: "px-5 py-2.5 rounded-xl bg-[#2d6a4f] text-white text-sm font-semibold hover:bg-[#235a40] transition-colors",
                                                                            children: T.submitExam
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 374,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            onClick: ()=>{
                                                                                setTakingExam(null);
                                                                                setExamAnswers({});
                                                                                setExamSubmitErr("");
                                                                            },
                                                                            className: "px-5 py-2.5 rounded-xl border border-[#e8dfc8] text-[#666] text-sm hover:bg-[#f5f0e8] transition-colors",
                                                                            children: T.cancelExam
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 375,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 373,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                            lineNumber: 349,
                                                            columnNumber: 31
                                                        }, this),
                                                        !activeExam && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mb-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 mb-3",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clipboard$2d$list$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ClipboardList$3e$__["ClipboardList"], {
                                                                            size: 14,
                                                                            className: "text-[#2d6a4f]"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 384,
                                                                            columnNumber: 35
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                            className: "text-sm font-semibold text-[#1a1a1a]",
                                                                            children: T.examsTitle
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 385,
                                                                            columnNumber: 35
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 383,
                                                                    columnNumber: 33
                                                                }, this),
                                                                available.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-xs text-[#ccc]",
                                                                    children: T.noExams
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 388,
                                                                    columnNumber: 35
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "space-y-2",
                                                                    children: available.map((ex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center justify-between bg-[#faf8f4] rounded-xl border border-[#e8dfc8] px-4 py-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "text-sm font-semibold text-[#1a1a1a]",
                                                                                            children: ex.title
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 394,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "text-xs text-[#aaa] mt-0.5",
                                                                                            children: [
                                                                                                T.questions(ex.questions.length),
                                                                                                " · ",
                                                                                                ex.date
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 395,
                                                                                            columnNumber: 43
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                    lineNumber: 393,
                                                                                    columnNumber: 41
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    onClick: ()=>{
                                                                                        setTakingExam({
                                                                                            examId: ex.id,
                                                                                            studentId: child.id
                                                                                        });
                                                                                        setExamAnswers({});
                                                                                        setExamSubmitErr("");
                                                                                    },
                                                                                    className: "px-3 py-1.5 rounded-lg bg-[#2d6a4f] text-white text-xs font-semibold hover:bg-[#235a40] transition-colors whitespace-nowrap ms-3",
                                                                                    children: T.startExam
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                    lineNumber: 397,
                                                                                    columnNumber: 41
                                                                                }, this)
                                                                            ]
                                                                        }, ex.id, true, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 392,
                                                                            columnNumber: 39
                                                                        }, this))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 390,
                                                                    columnNumber: 35
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                            lineNumber: 382,
                                                            columnNumber: 31
                                                        }, this),
                                                        taken.length > 0 && !activeExam && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mb-4",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                    className: "text-sm font-semibold text-[#1a1a1a] mb-3",
                                                                    children: T.examsTakenTitle
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 412,
                                                                    columnNumber: 33
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "space-y-2",
                                                                    children: taken.map((r)=>{
                                                                        const ex = exams.find((e)=>e.id === r.examId);
                                                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center justify-between bg-[#faf8f4] rounded-xl border border-[#e8dfc8] px-4 py-3",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "text-sm font-semibold text-[#1a1a1a]",
                                                                                            children: ex?.title ?? r.examId
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 419,
                                                                                            columnNumber: 43
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "text-xs text-[#aaa] mt-0.5",
                                                                                            children: r.dateTaken
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 420,
                                                                                            columnNumber: 43
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                    lineNumber: 418,
                                                                                    columnNumber: 41
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: `px-3 py-1 rounded-full text-xs font-bold border ms-3 ${scoreColor(r.score)}`,
                                                                                    children: [
                                                                                        r.correctCount,
                                                                                        "/",
                                                                                        r.totalCount,
                                                                                        " — ",
                                                                                        r.score,
                                                                                        "%"
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                    lineNumber: 422,
                                                                                    columnNumber: 41
                                                                                }, this)
                                                                            ]
                                                                        }, r.id, true, {
                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                            lineNumber: 417,
                                                                            columnNumber: 39
                                                                        }, this);
                                                                    })
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                    lineNumber: 413,
                                                                    columnNumber: 33
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                            lineNumber: 411,
                                                            columnNumber: 31
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                    lineNumber: 346,
                                                    columnNumber: 27
                                                }, this);
                                            })(),
                                            child.sessions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-[#ccc] text-center py-6",
                                                children: T.noSessions
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 437,
                                                columnNumber: 25
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                        className: "text-sm font-semibold text-[#1a1a1a] mb-3",
                                                        children: T.sessionDetail
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 440,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-3",
                                                        children: sorted.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "rounded-xl border border-[#f0ead8] p-4 bg-[#faf8f4]",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex flex-wrap items-center gap-2 mb-2",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-xs font-semibold text-[#555]",
                                                                                children: s.date
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                lineNumber: 445,
                                                                                columnNumber: 35
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: `flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border ${s.present ? "text-emerald-700 bg-emerald-50 border-emerald-200" : "text-red-700 bg-red-50 border-red-200"}`,
                                                                                children: s.present ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                                                                                            size: 11
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 447,
                                                                                            columnNumber: 52
                                                                                        }, this),
                                                                                        T.present
                                                                                    ]
                                                                                }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircle$3e$__["XCircle"], {
                                                                                            size: 11
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                            lineNumber: 447,
                                                                                            columnNumber: 97
                                                                                        }, this),
                                                                                        T.absent
                                                                                    ]
                                                                                }, void 0, true)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                lineNumber: 446,
                                                                                columnNumber: 35
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: `px-2 py-0.5 rounded-full text-xs font-medium border ${DISC_CLS[s.discipline]}`,
                                                                                children: T.disciplines[s.discipline]
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                lineNumber: 449,
                                                                                columnNumber: 35
                                                                            }, this),
                                                                            professorNames[s.professorId] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-xs text-[#aaa]",
                                                                                children: [
                                                                                    "— ",
                                                                                    professorNames[s.professorId]
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                lineNumber: 453,
                                                                                columnNumber: 37
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 444,
                                                                        columnNumber: 33
                                                                    }, this),
                                                                    s.memorization && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "text-xs text-[#555] mb-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "font-semibold text-[#c9a84c]",
                                                                                children: T.memo
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                                lineNumber: 458,
                                                                                columnNumber: 37
                                                                            }, this),
                                                                            " ",
                                                                            s.memorization
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 457,
                                                                        columnNumber: 35
                                                                    }, this),
                                                                    s.comment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "text-xs text-[#666] italic border-s-2 border-[#c9a84c]/40 ps-3 mt-2",
                                                                        children: [
                                                                            "“",
                                                                            s.comment,
                                                                            "”"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                        lineNumber: 462,
                                                                        columnNumber: 35
                                                                    }, this)
                                                                ]
                                                            }, s.id, true, {
                                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                                lineNumber: 443,
                                                                columnNumber: 31
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                        lineNumber: 441,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                                lineNumber: 439,
                                                columnNumber: 25
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                        lineNumber: 313,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, child.id, true, {
                                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                                lineNumber: 266,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/dashboard/parent/page.tsx",
                        lineNumber: 256,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/dashboard/parent/page.tsx",
                lineNumber: 218,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/dashboard/parent/page.tsx",
        lineNumber: 187,
        columnNumber: 5
    }, this);
}
_s(ParentDashboard, "rEmre3nKE2a7FYU2Y1aqgqw8rmI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$LanguageContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLanguage"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ParentDashboard;
var _c;
__turbopack_context__.k.register(_c, "ParentDashboard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0sc0_5p._.js.map